<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elmento valida a presença do campo de erro ao preencher os campos de dados da conta</description>
   <name>001_Informacao criacao de conta</name>
   <tag></tag>
   <elementGuidId>196a3be6-f93e-4841-8aea-77128c08a6f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;center-align-buttons&quot;]//*[@data-key=&quot;error&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
