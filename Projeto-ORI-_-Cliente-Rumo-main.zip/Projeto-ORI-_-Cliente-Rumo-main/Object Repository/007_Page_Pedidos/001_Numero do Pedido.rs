<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento busca o número do pedido</description>
   <name>001_Numero do Pedido</name>
   <tag></tag>
   <elementGuidId>352a9bdc-fa71-415a-86f3-7242d38619be</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Número do pedido&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
