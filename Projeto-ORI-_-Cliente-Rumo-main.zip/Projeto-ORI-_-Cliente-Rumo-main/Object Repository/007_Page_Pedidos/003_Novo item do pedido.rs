<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar no botão de Novo Item do Pedido</description>
   <name>003_Novo item do pedido</name>
   <tag></tag>
   <elementGuidId>830704b4-efce-43c2-9d36-d118f746586a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[normalize-space(text())=&quot;Novo item do pedido&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
