<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento apresenta o quadro na tela de Tabela de Preços</description>
   <name>002_Campo da Tabela de precos</name>
   <tag></tag>
   <elementGuidId>91e443a1-d893-4e56-bc94-87b3643d80bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Tabelas de preços&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
