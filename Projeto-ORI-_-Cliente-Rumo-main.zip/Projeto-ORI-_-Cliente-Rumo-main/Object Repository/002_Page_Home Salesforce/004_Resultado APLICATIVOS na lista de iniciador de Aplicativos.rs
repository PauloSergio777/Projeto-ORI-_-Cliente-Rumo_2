<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>004_Resultado APLICATIVOS na lista de iniciador de Aplicativos</name>
   <tag></tag>
   <elementGuidId>fb212f4d-64c3-4552-be03-63fa5108be4e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h3[contains(text(),&quot;Aplicativos&quot;)]//following::lightning-formatted-rich-text/span/p/b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
