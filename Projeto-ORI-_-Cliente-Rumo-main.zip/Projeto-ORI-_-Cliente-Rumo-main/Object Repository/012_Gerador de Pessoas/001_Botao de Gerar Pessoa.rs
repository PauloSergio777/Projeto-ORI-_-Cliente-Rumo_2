<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite o clique no botao de gerar pessoas</description>
   <name>001_Botao de Gerar Pessoa</name>
   <tag></tag>
   <elementGuidId>7a528ee4-f903-437c-90c4-93c4cdfbb5d7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@id=&quot;nv-new-generator-people&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
