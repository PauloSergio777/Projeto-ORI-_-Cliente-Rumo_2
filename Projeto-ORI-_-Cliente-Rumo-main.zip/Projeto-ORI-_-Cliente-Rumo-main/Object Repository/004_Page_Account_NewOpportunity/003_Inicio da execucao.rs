<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento valida a presença do campo e permite inserir dados no campo</description>
   <name>003_Inicio da execucao</name>
   <tag></tag>
   <elementGuidId>29cdb611-bffd-440d-bfc9-ddfd86c93ec0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),&quot;Início da execução&quot;)]//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
