<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento move para a lista de escolhidos</description>
   <name>006_Mover para escolhidos</name>
   <tag></tag>
   <elementGuidId>76525420-b871-4071-9199-fd3ad9c90962</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@title=&quot;Mover a seleção para Escolhidos&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
