<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento valida a presença do campo e permite a inserção de dados no campo</description>
   <name>004_Fim da execucao</name>
   <tag></tag>
   <elementGuidId>16f2ab6b-8c77-4569-854c-7d72635182f2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),&quot;Fim da execução&quot;)]//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
