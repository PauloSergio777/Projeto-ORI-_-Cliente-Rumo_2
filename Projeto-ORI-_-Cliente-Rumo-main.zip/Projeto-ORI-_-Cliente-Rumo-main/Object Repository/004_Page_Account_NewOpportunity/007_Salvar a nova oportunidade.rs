<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite salvar os dados da nova oportunidade</description>
   <name>007_Salvar a nova oportunidade</name>
   <tag></tag>
   <elementGuidId>6397d45a-6b0a-47f2-81d8-1df43b096b94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@title=&quot;Salvar&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
