<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento captura um valor no quadro de corredor disponiveis</description>
   <name>005_Corredor disponiveis</name>
   <tag></tag>
   <elementGuidId>ec7e4c6f-f0b7-49e6-89af-7e565a9cc4fe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),&quot;Malha Central&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
