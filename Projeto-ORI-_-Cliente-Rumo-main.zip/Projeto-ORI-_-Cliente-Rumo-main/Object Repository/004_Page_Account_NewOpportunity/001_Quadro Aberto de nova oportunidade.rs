<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento valida se o quadro da nova oportunidade foi criada com sucesso</description>
   <name>001_Quadro Aberto de nova oportunidade</name>
   <tag></tag>
   <elementGuidId>64defa40-c831-42ab-9364-37f07a614094</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h2[contains(text(),&quot;Criar oportunidade&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
