<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Imagem de mkt da tela de login carregada</description>
   <name>001_Imagem da tela de login</name>
   <tag></tag>
   <elementGuidId>65dce05e-8280-4a86-8874-32161eb420be</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//iframe[contains(@id,&quot;marketing&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
