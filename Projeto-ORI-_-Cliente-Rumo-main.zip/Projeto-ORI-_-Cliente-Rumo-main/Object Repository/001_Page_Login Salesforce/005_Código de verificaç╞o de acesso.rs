<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este campo solicita o código de verificação de acesso ao SF (somente se for primeiro acesso ao amibente)</description>
   <name>005_Código de verificação de acesso</name>
   <tag></tag>
   <elementGuidId>1ee6f678-b870-4f20-bd5e-306b0275b322</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[contains(text(),&quot;Código de verificação&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
