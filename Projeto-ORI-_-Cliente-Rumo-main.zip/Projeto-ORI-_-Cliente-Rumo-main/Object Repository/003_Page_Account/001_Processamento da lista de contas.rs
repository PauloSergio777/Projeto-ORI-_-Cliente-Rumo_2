<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento aguarda o processamento completo das contas apresentadas na lista de contas</description>
   <name>001_Processamento da lista de contas</name>
   <tag></tag>
   <elementGuidId>b8a4d442-206d-4e86-82a9-2c59960dee1b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[contains(text(),&quot;Nome da conta&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
