<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento valida o carregamento da tela de inserção de dados para nova de conta</description>
   <name>014_Quadro de inserção de dados Nova Conta</name>
   <tag></tag>
   <elementGuidId>5676b26c-4f52-4d18-9ae4-d8b32b5c84ab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h2[contains(text(),&quot;Nova Conta:&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
