<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite efetuar o filtro do tipo de contas de acordo com os filtros ja criados</description>
   <name>003_Pesquisa de filtros na lista</name>
   <tag></tag>
   <elementGuidId>f0b1f96a-930e-4a9d-839a-078a3027fb2f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[@type=&quot;text&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
