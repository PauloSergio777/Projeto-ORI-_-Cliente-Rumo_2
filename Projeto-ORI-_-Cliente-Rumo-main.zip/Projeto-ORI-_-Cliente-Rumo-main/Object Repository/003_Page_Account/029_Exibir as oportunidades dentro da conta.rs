<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O sistema devera abrir a lista das oportunidades criadas dentro do objeto conta</description>
   <name>029_Exibir as oportunidades dentro da conta</name>
   <tag></tag>
   <elementGuidId>515a5573-3093-44a1-9a60-d33d33d6068c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//img[@title=&quot;Oportunidades&quot;]//following::a[7]/span</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
