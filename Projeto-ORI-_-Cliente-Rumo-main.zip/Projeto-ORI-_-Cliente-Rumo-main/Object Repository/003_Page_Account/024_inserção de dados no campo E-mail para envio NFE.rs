<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir dados no campo E-mail para envio NFE</description>
   <name>024_inserção de dados no campo E-mail para envio NFE</name>
   <tag></tag>
   <elementGuidId>b73c116a-995c-473b-81c6-4dafba2dd765</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),&quot;E-mail para envio NFE&quot;)]//following::textarea[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
