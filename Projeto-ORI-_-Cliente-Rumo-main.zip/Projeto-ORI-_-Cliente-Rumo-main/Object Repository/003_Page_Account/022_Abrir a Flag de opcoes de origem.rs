<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite abrir a flag de opções de origem da conta</description>
   <name>022_Abrir a Flag de opcoes de origem</name>
   <tag></tag>
   <elementGuidId>8693086e-8a28-415a-ae46-54771f599c44</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@aria-label=&quot;Origem, --Nenhum--&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
