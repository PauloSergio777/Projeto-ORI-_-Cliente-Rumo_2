<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que clique no botão de novo contato na tela da conta</description>
   <name>031_Botao de Criar novo Contato</name>
   <tag></tag>
   <elementGuidId>3287d36f-e2bb-4aa2-9932-9f0c7fd5f317</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[normalize-space(text())=&quot;Novo contato&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
