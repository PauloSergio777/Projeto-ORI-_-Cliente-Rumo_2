<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento localiza a lista de oportunidades em relacionado da conta</description>
   <name>008_ Lista de Relacionados oportunidade</name>
   <tag></tag>
   <elementGuidId>9a7dd696-d288-40a9-a629-64b2dcb6dba9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//img[@title=&quot;Oportunidades&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
