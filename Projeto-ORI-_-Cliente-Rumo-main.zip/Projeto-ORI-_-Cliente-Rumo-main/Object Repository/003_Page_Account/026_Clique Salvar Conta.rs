<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar em Salvar após inserir os dados da nova conta</description>
   <name>026_Clique Salvar Conta</name>
   <tag></tag>
   <elementGuidId>bf5787d4-4b6d-404c-a2cb-9b14bb4059ac</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[normalize-space(text())='Salvar']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
