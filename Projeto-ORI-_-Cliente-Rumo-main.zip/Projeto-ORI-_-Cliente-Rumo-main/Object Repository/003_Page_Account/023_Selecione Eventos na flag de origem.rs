<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento apresenta a opção de selecionar o tipo de Origem da Conta</description>
   <name>023_Selecione Eventos na flag de origem</name>
   <tag></tag>
   <elementGuidId>e4ea3b23-1b0f-47e3-a159-8136dfc11eb4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),'Eventos')]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
