<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento localiza na tela de conta o quadro de oportunidades criadas na conta</description>
   <name>028_Quadro de oportunidades criadas na conta</name>
   <tag></tag>
   <elementGuidId>d73039c6-1214-43ba-8de3-47dfaa13667b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//img[@title=&quot;Oportunidades&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
