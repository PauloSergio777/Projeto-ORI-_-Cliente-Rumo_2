<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite a inserção de nome da conta para busca</description>
   <name>005_Pesquisa de contas na lista</name>
   <tag></tag>
   <elementGuidId>00442587-94ff-420d-8c77-568a7c50f460</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[@name=&quot;Account-search-input&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
