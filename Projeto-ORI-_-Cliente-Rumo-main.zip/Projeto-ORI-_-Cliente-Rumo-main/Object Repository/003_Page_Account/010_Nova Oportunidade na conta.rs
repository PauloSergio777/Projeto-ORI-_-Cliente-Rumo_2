<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento localiza na tela a opção de clicar no botão de nova oportunidade</description>
   <name>010_Nova Oportunidade na conta</name>
   <tag></tag>
   <elementGuidId>5297ef54-81d3-497b-aa6e-15f10da7363a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[contains(text(),&quot;Nova oportunidade&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
