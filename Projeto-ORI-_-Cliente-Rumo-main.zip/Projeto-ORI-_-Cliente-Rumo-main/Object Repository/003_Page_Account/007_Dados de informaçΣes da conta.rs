<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento serve para aguardar o processamento da pagina da conta acessada</description>
   <name>007_Dados de informações da conta</name>
   <tag></tag>
   <elementGuidId>ca1af88c-792f-4f3e-a944-00e606ec1ddf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),&quot;Informações sobre a conta&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
