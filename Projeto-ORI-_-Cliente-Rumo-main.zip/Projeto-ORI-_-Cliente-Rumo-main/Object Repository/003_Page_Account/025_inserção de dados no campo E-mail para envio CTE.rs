<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir dados no campo E-mail para envio NFE</description>
   <name>025_inserção de dados no campo E-mail para envio CTE</name>
   <tag></tag>
   <elementGuidId>d7cac64a-4ea4-45fb-ad0a-24185fa6287f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),&quot;E-mail para envio CTE&quot;)]//following::textarea[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
