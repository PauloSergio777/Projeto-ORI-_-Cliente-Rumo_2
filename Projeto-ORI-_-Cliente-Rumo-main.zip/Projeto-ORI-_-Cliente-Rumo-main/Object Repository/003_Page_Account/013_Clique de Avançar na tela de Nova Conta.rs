<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite o clique de avançar na tela de Nova Conta</description>
   <name>013_Clique de Avançar na tela de Nova Conta</name>
   <tag></tag>
   <elementGuidId>d7f7a320-8ed2-4db7-abc5-98b5aec09f32</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),&quot;Avançar&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
