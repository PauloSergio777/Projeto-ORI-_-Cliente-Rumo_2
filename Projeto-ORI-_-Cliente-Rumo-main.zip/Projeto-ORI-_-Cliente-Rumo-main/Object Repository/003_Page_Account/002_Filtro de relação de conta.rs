<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento seleciona o tipo de filtração das contas no sistema</description>
   <name>002_Filtro de relação de conta</name>
   <tag></tag>
   <elementGuidId>aa3aa532-3327-447b-86b5-4fdea67ca388</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),&quot;Recente&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
