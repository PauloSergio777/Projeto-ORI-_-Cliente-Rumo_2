<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite a escolha do tipo de registro na conta</description>
   <name>012_Selecione o tipo do registro de conta</name>
   <tag></tag>
   <elementGuidId>8f5c2009-3d88-4afd-b91b-9af38a666d24</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),&quot;Cliente - Matriz&quot;)]//preceding::span[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
