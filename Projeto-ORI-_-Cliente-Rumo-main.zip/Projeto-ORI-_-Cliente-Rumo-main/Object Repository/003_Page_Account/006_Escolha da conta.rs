<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite selecionar o link da primeira conta localizada após a busca</description>
   <name>006_Escolha da conta</name>
   <tag></tag>
   <elementGuidId>47a12a5c-ca1a-4cf3-842e-f00b35c7fabc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//td[@role=&quot;gridcell&quot;][1]//following::a[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
