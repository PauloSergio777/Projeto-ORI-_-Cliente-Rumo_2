<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir dados no campo Ramo de Atividade</description>
   <name>021_Inserção de dados no campo Ramo de Atividade</name>
   <tag></tag>
   <elementGuidId>39bc1848-7f36-476c-bb1e-18bff5f96ac6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),&quot;Ramo de atividade&quot;)]//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
