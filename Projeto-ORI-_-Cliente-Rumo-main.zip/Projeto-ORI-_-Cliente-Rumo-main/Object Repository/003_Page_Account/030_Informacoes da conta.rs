<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento localiza o campo de Equipe de Conta</description>
   <name>030_Informacoes da conta</name>
   <tag></tag>
   <elementGuidId>72d7564f-a58a-444d-8230-297f5904ef48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),&quot;Informações do sistema&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
