<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento valida a presenca do campo em Conta</description>
   <name>027_Valide a presenca do campo Informacoes de Conta</name>
   <tag></tag>
   <elementGuidId>946b2dfa-1819-4960-ad57-abdc0f615239</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())='Informações sobre a conta']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
