<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir dados no campo Razao Social</description>
   <name>019_Inserção de dados da Razao Social</name>
   <tag></tag>
   <elementGuidId>466b6e60-9e95-41bf-a082-0b0d8248952c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[contains(text(),&quot;Razão social&quot;)]//following::textarea[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
