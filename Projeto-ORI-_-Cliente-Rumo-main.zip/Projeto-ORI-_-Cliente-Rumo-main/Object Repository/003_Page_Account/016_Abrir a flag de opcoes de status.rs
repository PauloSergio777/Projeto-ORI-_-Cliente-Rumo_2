<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento apresenta as opções de status da nova conta</description>
   <name>016_Abrir a flag de opcoes de status</name>
   <tag></tag>
   <elementGuidId>cf591664-7935-4b70-88ea-4f4f1b11abde</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@aria-label=&quot;Status, --Nenhum--&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
