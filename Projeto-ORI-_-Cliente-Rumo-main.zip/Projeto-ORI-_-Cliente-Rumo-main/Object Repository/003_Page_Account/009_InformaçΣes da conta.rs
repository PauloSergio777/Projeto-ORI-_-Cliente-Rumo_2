<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Apresenta informações da conta acessada</description>
   <name>009_Informações da conta</name>
   <tag></tag>
   <elementGuidId>9df1da19-1bec-4001-a022-d724ecc9104e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[contains(text(),&quot;Informações do sistema&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
