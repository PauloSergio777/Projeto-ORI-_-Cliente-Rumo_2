<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento traz a opção de selecionar o todas as contas no filtro</description>
   <name>004_Seleção da opção de Todas as contas</name>
   <tag></tag>
   <elementGuidId>84655515-54c0-4b03-8cd4-b8f35752a4a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//Mark[contains(text(),&quot;Todas as Contas&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
