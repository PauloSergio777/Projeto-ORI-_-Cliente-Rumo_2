<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite que cliquemos no botão de gerar empresa</description>
   <name>002_Botao de Gerar Empresa</name>
   <tag></tag>
   <elementGuidId>b7dbfc96-e38e-456d-9f29-8a5260389c23</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[@id=&quot;nv-new-generator-company&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
