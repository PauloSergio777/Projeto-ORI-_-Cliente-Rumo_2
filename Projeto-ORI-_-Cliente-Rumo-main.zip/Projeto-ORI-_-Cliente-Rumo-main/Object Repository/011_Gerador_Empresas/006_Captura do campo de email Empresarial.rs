<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite que seja coletado o dado do campo email</description>
   <name>006_Captura do campo de email Empresarial</name>
   <tag></tag>
   <elementGuidId>f182a400-7e38-4582-b1b8-4525ecdb0a46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[@id=&quot;nv-field-email&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
