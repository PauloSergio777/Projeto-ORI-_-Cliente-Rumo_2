<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite que seja capturado o CNPJ gerado</description>
   <name>004_Captura do campo CNPJ</name>
   <tag></tag>
   <elementGuidId>9904f966-ce26-4148-81ca-3b92e552f015</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[@id=&quot;nv-field-cnpj&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
