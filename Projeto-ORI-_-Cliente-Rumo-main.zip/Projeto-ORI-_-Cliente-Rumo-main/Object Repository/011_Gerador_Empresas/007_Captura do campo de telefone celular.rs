<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que seja coletado o telefone celular</description>
   <name>007_Captura do campo de telefone celular</name>
   <tag></tag>
   <elementGuidId>c46bbda7-65c6-4f1e-bafb-51e49171e4b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[@id=&quot;nv-field-cellphone&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
