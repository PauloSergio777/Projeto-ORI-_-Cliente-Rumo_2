<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que o checkbox de não pontuação seja preenchido</description>
   <name>001_CheckBox de nao gerar pontuacao</name>
   <tag></tag>
   <elementGuidId>337c416d-09b5-47f9-8102-b0c3d013629b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@id=&quot;pontuacao_nao&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
