<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que coletamos o nome gerado.</description>
   <name>003_Captura do campo Nome</name>
   <tag></tag>
   <elementGuidId>85e43afb-a717-41e4-bc82-a0fe61a19afe</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[@id=&quot;nv-field-company-name&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
