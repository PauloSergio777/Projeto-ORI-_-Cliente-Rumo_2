<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite que seja coletado os dados do campo Inscricao Estadual</description>
   <name>005_Captura do campo Inscricao Estadual</name>
   <tag></tag>
   <elementGuidId>e2350491-a49b-4869-bd15-94848f319bcd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[@id=&quot;nv-field-ie&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
