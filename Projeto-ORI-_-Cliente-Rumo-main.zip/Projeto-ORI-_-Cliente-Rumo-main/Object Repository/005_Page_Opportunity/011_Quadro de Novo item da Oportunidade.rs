<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento valida a presença do quadro de novo item da oportunidade</description>
   <name>011_Quadro de Novo item da Oportunidade</name>
   <tag></tag>
   <elementGuidId>be656e98-a626-4724-a821-3d220ba7b94b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h4[normalize-space(text())=&quot;Novo item da oportunidade&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
