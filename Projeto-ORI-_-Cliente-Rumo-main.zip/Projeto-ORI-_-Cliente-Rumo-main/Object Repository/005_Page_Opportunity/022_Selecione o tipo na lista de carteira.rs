<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite selecionar o tipo no campo carteira</description>
   <name>022_Selecione o tipo na lista de carteira</name>
   <tag></tag>
   <elementGuidId>f5f41333-053e-49bd-b868-09d0f14567c7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[@class=&quot;slds-media__body&quot;]//span[normalize-space(text())=&quot;${GlobalVariable.Carteira}&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
