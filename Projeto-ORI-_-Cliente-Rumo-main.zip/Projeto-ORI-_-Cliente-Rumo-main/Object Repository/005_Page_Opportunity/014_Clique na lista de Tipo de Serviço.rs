<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento após executado, apresenta as opções de tipos de serviços</description>
   <name>014_Clique na lista de Tipo de Serviço</name>
   <tag></tag>
   <elementGuidId>467d5042-4266-4035-b3f0-e1e2a79f52d6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Tipo de serviço&quot;]//following::div[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
