<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento clica na lista de papel da equipe</description>
   <name>007_Clique no Papel da Equipe</name>
   <tag></tag>
   <elementGuidId>170ccc4a-fb80-44f6-8cc4-d9072fd0f2a5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[normalize-space(text())=&quot;Acesso de oportunidade&quot;]//following::tr[1]/th[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
