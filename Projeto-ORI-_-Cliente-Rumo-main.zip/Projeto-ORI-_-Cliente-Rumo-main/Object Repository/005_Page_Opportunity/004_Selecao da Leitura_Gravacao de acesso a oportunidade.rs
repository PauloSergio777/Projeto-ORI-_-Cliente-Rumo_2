<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento localiza a opção de Leitura e Gravacao não opções de acesso de oportunidade</description>
   <name>004_Selecao da Leitura_Gravacao de acesso a oportunidade</name>
   <tag></tag>
   <elementGuidId>ed35edf6-169d-4df8-a6c7-33265747af5a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[normalize-space(text())=&quot;Leitura/Gravação&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
