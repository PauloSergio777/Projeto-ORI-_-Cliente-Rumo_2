<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento apresenta a lista de opções de carteira na criação da oportunidade</description>
   <name>021_Clique para exibir a lista de Carteiras na criação da Oportunidade</name>
   <tag></tag>
   <elementGuidId>26660dc9-cf18-426a-9182-77929528ffa6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//Label[normalize-space(text())=&quot;Carteira&quot;]//following::div[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
