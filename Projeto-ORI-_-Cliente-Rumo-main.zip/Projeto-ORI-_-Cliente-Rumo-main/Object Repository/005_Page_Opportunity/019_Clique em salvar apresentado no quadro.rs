<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite salvar ao inserir as informações nos campos obrigatorios do quadro</description>
   <name>019_Clique em salvar apresentado no quadro</name>
   <tag></tag>
   <elementGuidId>1a1656a9-a1f9-4efa-9cbb-6f1394d69984</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[normalize-space(text())=&quot;Salvar&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
