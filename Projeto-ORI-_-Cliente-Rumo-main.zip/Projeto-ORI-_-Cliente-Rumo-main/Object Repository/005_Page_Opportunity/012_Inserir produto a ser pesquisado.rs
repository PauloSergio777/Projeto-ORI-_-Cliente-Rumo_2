<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir no campo de pesquisa de produto um texto para validar a presença de um produto no sistema</description>
   <name>012_Inserir produto a ser pesquisado</name>
   <tag></tag>
   <elementGuidId>91601f1d-0ba7-458b-9ae0-031655918779</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Produto&quot;]//following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
