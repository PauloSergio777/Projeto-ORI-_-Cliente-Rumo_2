<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento valida a presença do quadro de Adicionar Membros da equipe da oportunidade</description>
   <name>002_Quadro de Adicionar Membros da equipe da oportunidade</name>
   <tag></tag>
   <elementGuidId>0640095b-4318-46d4-89f2-a0d48e18dbcc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h2[contains(text(),&quot;Adicionar Membros da equipe da oportunidade&quot;)]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
