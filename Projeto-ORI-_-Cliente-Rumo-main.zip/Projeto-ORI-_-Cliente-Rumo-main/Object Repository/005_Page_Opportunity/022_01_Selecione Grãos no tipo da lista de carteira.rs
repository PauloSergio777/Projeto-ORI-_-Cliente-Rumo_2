<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite selecionar o tipo no campo carteira</description>
   <name>022_01_Selecione Grãos no tipo da lista de carteira</name>
   <tag></tag>
   <elementGuidId>8578d817-6668-4725-a87d-645021aa9a3d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@class=&quot;slds-media__body&quot;]//span[normalize-space(text())=&quot;Grãos&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
