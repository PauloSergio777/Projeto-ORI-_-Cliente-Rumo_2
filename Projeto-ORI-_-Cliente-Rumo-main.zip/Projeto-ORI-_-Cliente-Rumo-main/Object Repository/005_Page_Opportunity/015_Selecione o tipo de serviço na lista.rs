<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento localiza e clica no item exibido na lista de tipo de serviços</description>
   <name>015_Selecione o tipo de serviço na lista</name>
   <tag></tag>
   <elementGuidId>506b96e4-b691-40ca-a25b-0949bb4d12a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Transporte Ferroviário&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
