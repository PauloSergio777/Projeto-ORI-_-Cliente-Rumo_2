<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir um valor no campo de volume total</description>
   <name>018_Inserir um valor no campo de Volume Total</name>
   <tag></tag>
   <elementGuidId>8daa9e0b-8441-4ea5-bc83-7c9bbb7a736c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//Label[normalize-space(text())=&quot;Volume total&quot;]//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
