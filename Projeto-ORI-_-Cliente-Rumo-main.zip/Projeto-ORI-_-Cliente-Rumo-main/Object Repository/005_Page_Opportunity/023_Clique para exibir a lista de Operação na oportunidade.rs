<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que clique na lista de operação da oportunidade</description>
   <name>023_Clique para exibir a lista de Operação na oportunidade</name>
   <tag></tag>
   <elementGuidId>53647e19-a4cc-4d9a-ace8-29f3fcf1fd27</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//Label[normalize-space(text())=&quot;Operação&quot;]//following::div[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
