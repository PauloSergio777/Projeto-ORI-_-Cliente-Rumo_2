<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento inicia a criação de um novo item da oportunidade</description>
   <name>010_Clique do novo item da oportunidade</name>
   <tag></tag>
   <elementGuidId>bd8d7262-d109-41fa-b67b-2ac3f6e693d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[normalize-space(text())=&quot;Novo item da oportunidade&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
