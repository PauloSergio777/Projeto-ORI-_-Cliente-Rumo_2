<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir Membro na equipe da oportunidade</description>
   <name>001_Adicionar Membro da equipe da oportunidade</name>
   <tag></tag>
   <elementGuidId>9ceb39ae-c492-4c33-aed0-440e5779c13b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@title=&quot;Adicionar Membros da equipe da oportunidade&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
