<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar na lista de operaçao apresentada</description>
   <name>024_selecione o tipo na lista de operacao apresentada</name>
   <tag></tag>
   <elementGuidId>6119e4ec-50f3-425d-adfc-95804d2227b8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@class=&quot;slds-media__body&quot;]//span[normalize-space(text())=&quot;Sul&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
