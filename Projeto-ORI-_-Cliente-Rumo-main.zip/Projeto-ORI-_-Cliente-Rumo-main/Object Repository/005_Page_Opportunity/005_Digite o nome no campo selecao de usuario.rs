<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento localiza abre o leque de opções do usuario</description>
   <name>005_Digite o nome no campo selecao de usuario</name>
   <tag></tag>
   <elementGuidId>0da2e247-0cac-4687-ac13-b54b50088aea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@title=&quot;Pesquisar Pessoas&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
