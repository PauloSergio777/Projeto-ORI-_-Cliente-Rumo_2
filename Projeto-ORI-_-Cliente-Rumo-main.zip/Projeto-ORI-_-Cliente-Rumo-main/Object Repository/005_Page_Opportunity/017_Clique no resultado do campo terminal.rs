<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento clica no resultado do terminal após inserção do texto</description>
   <name>017_Clique no resultado do campo terminal</name>
   <tag></tag>
   <elementGuidId>4716c29c-5f20-499b-b9d6-e7dece90ad70</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//lightning-icon[@icon-name=&quot;standard:account&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
