<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento clica no quadro e abre o leque de opções de acesso a oportunidade</description>
   <name>003_Clique para selecao de Acesso de Oportunidade</name>
   <tag></tag>
   <elementGuidId>e5363904-030b-4472-9d5b-e70b7045d5d8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[normalize-space(text())=&quot;Acesso de oportunidade&quot;]//following::tr[1]/td[3]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
