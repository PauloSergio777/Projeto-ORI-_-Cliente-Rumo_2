<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite inserir um texto no campo de terminal</description>
   <name>016_Digite no campo de Terminal o nome de uma conta</name>
   <tag></tag>
   <elementGuidId>0f6f5a79-012b-4b2d-bac2-ffd99cfbad5e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//Label[normalize-space(text())=&quot;Terminal&quot;]//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
