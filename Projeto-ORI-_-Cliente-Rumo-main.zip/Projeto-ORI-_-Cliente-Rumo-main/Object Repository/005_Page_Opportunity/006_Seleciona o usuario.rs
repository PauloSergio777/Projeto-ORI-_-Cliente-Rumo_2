<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento seleciona a opção disponivel na tela</description>
   <name>006_Seleciona o usuario</name>
   <tag></tag>
   <elementGuidId>42e7e855-d16d-470c-96d0-4c3cb6c5f4ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//img[@title=&quot;Usuário&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
