<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite inserir dados no campo da data de nascimento</description>
   <name>004_Campo de insercao da data de nascimento</name>
   <tag></tag>
   <elementGuidId>ac9d5837-8a5e-4fb3-ba99-d5aaaf688020</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Data de nascimento&quot;]//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
