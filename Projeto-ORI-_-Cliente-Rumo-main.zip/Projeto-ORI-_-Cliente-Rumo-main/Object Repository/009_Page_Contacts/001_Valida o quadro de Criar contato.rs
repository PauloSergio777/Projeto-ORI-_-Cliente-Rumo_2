<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento valida a presença do quadro de criar contato.</description>
   <name>001_Valida o quadro de Criar contato</name>
   <tag></tag>
   <elementGuidId>a2bf4fb8-c7c6-4908-ad82-e21bd4d608b7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h2[normalize-space(text())=&quot;Criar contato&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
