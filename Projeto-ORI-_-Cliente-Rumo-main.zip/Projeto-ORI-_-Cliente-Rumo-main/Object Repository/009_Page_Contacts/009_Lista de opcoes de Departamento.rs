<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elementos abre a flag da lista de departamentos</description>
   <name>009_Lista de opcoes de Departamento</name>
   <tag></tag>
   <elementGuidId>3ba6374e-f6c8-4d27-9b34-78eee478c4d0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Departamento&quot;]//following::button[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
