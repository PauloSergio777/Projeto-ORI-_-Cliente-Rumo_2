<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite seleciona na lista apresentada</description>
   <name>007_Selecione na lista de Funcao</name>
   <tag></tag>
   <elementGuidId>7738e038-735a-45cc-8bcb-83c943f484b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Analista&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
