<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que cliquemos no botão para enviar a lista de escolhidos o item carteira</description>
   <name>013_Clique para a inserir na lista de escolhidos da carteira</name>
   <tag></tag>
   <elementGuidId>a9048b3e-82db-4dce-b3ba-b6fd805531d0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;slds-dueling-list&quot;]//*[normalize-space(text())=&quot;Grãos&quot;]//following::button[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
