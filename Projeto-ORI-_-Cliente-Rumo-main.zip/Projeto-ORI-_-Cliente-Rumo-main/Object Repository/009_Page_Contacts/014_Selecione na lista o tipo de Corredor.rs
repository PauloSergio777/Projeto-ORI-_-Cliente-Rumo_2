<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que seja escolhido o tipo do corredor</description>
   <name>014_Selecione na lista o tipo de Corredor</name>
   <tag></tag>
   <elementGuidId>ee1cbf0f-6b58-40c4-a08d-7294f3f45a11</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;slds-dueling-list&quot;]//*[normalize-space(text())=&quot;Malha Central&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
