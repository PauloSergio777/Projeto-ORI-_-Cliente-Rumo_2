<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que localizamos o quadro de opcoes das informações adicionais</description>
   <name>011_Quadro de informacoes adicionais</name>
   <tag></tag>
   <elementGuidId>7ed00a1b-4c5a-4de7-8566-d05fb276b78a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Informações adicionais&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
