<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que enviamos para a lista de escolhidos o tipo do corredor</description>
   <name>015_Clique para inserir na lista de escolhidos do tipo de Corredor</name>
   <tag></tag>
   <elementGuidId>923602fe-eee5-4790-9538-ca4e18e7d139</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;slds-dueling-list&quot;]//*[normalize-space(text())=&quot;Malha Central&quot;]//following::button[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
