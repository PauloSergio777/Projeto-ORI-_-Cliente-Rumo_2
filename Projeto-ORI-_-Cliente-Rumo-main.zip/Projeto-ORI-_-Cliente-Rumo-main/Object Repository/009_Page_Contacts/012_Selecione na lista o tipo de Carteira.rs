<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite selecionarmos um item da lista de Carteira</description>
   <name>012_Selecione na lista o tipo de Carteira</name>
   <tag></tag>
   <elementGuidId>27945990-141a-4d5c-94f7-aee67666294e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;slds-dueling-list&quot;]//*[normalize-space(text())=&quot;Grãos&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
