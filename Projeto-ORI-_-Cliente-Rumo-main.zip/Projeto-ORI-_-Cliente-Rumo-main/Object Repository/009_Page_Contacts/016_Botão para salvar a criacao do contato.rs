<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O sistema devera permitir Salvar o contato com sucesso.</description>
   <name>016_Botão para salvar a criacao do contato</name>
   <tag></tag>
   <elementGuidId>d4c976b7-8a44-4dee-a696-6c45f19664ff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//button[normalize-space(text())=&quot;Salvar&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
