<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite a inserção de dados no campo de email</description>
   <name>005_Campo de insercao do email</name>
   <tag></tag>
   <elementGuidId>fcaaa5b5-2191-4ee4-80eb-55566bd81740</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Email&quot;]//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
