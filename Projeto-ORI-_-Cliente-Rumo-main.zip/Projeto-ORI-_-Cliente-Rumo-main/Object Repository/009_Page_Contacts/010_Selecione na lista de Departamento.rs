<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que selecionamos uma opção na lista de Departamento</description>
   <name>010_Selecione na lista de Departamento</name>
   <tag></tag>
   <elementGuidId>acf5fc4e-59be-4dd7-892a-17015b3c504b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Comercial&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
