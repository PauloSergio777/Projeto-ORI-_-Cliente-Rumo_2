<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite a inserção de dados no campo de Sobrenome</description>
   <name>003_Campo de insercao do Sobrenome</name>
   <tag></tag>
   <elementGuidId>6771d9f2-53f9-4449-ac83-c920f7eff566</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Sobrenome&quot;]//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
