<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento traz o campo de relacionado após salvamento do novo contato</description>
   <name>017_Campo de relacionado após salvamento</name>
   <tag></tag>
   <elementGuidId>df6758a6-8d2b-44a9-89bd-a64b6de95248</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[normalize-space(text())=&quot;Relacionado&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
