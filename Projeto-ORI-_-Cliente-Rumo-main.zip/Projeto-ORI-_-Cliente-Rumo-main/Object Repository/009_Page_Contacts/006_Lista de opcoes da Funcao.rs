<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicarmos na lista de opcoes apresentadas no campo Funcao</description>
   <name>006_Lista de opcoes da Funcao</name>
   <tag></tag>
   <elementGuidId>59feccef-afa8-4599-b768-5a9fb3cfc2ec</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Função&quot;]//following::button[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
