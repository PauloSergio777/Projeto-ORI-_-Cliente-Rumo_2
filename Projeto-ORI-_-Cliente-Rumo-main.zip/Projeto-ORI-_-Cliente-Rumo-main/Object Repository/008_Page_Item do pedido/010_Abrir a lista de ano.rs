<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que abra a lista de ano no quadro</description>
   <name>010_Abrir a lista de ano</name>
   <tag></tag>
   <elementGuidId>23645a6e-37f2-42b4-958e-bcbc6ef88362</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//Label[normalize-space(text())=&quot;Ano&quot;]//following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
