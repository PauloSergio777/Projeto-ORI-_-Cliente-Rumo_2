<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento valida a presença da lista de item de Contraproposta.</description>
   <name>015_Elemento Contraproposta</name>
   <tag></tag>
   <elementGuidId>effcc00f-4bf4-405f-b7b1-3becc54cca68</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//lightning-accordion-section[@role=&quot;listitem&quot;]//span[@title=&quot;Contraproposta&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
