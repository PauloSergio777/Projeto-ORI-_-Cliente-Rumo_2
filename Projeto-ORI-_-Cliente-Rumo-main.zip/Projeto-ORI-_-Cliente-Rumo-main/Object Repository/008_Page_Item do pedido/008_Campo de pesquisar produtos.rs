<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite a pesquisa de produtos no sistema</description>
   <name>008_Campo de pesquisar produtos</name>
   <tag></tag>
   <elementGuidId>86bb18b7-d9c8-4c23-a243-f74e0bbdd529</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@placeholder=&quot;Pesquisar Produtos...&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
