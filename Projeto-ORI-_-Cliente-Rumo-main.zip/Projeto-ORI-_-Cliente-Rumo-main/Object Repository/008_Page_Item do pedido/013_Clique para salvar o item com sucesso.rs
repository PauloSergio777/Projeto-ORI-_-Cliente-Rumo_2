<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite que o item seja salvo com sucesso</description>
   <name>013_Clique para salvar o item com sucesso</name>
   <tag></tag>
   <elementGuidId>2883f418-75c7-4dea-8623-032178fc8b96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Volume&quot;]//following::button[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
