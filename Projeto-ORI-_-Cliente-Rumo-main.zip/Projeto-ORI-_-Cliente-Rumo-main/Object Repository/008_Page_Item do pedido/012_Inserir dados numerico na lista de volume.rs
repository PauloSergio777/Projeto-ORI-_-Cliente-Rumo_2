<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite que o campo de volume seja preenchido de acordo com o mes</description>
   <name>012_Inserir dados numerico na lista de volume</name>
   <tag></tag>
   <elementGuidId>5c8c13c2-5212-4da4-b650-4e3d724e2b5a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Maio&quot;]//following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
