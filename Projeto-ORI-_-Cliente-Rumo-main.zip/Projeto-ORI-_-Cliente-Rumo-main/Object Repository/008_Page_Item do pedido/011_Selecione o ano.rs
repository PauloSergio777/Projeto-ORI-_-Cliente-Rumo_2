<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite selecionar o ano na lista</description>
   <name>011_Selecione o ano</name>
   <tag></tag>
   <elementGuidId>4ed7adcb-4704-476d-b168-eee984d76c21</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@data-value=&quot;2023&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
