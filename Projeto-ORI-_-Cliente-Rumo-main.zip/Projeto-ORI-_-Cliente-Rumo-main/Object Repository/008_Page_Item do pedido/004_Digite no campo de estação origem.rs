<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite inserir dados no campo estação origem</description>
   <name>004_Digite no campo de estação origem</name>
   <tag></tag>
   <elementGuidId>6f339477-1c9b-44bc-8832-1ddf0ad3200c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Estação de origem&quot;]//following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
