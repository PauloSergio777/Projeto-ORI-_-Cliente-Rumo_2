<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite escolher o tipo de serviço</description>
   <name>002_Expandir a lista de Tipo de Serviço</name>
   <tag></tag>
   <elementGuidId>87be784a-c1fc-4601-9b58-8392d0d2c110</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Tipo de serviço&quot;]//following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
