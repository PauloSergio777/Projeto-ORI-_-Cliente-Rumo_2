<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento valida a presença do campo de preço base na tela.</description>
   <name>014_Elemento Preço Base</name>
   <tag></tag>
   <elementGuidId>4295f828-747f-471e-b677-270202a7a6e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//lightning-accordion-section[@role=&quot;listitem&quot;]//span[@title=&quot;Preço base&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
