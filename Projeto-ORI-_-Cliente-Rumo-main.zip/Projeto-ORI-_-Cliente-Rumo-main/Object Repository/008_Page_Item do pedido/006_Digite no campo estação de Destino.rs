<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse eleemento permite digitar no campo de estação de destino</description>
   <name>006_Digite no campo estação de Destino</name>
   <tag></tag>
   <elementGuidId>df97d00a-9a81-40ae-9a0d-7a5583fc7024</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Estação de destino&quot;]//following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
