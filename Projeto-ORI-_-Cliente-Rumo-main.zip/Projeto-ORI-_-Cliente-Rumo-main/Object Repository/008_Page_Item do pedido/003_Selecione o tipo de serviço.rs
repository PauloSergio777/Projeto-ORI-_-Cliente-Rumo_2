<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar no tipo de serviço apresentado na lista</description>
   <name>003_Selecione o tipo de serviço</name>
   <tag></tag>
   <elementGuidId>b06d8bb2-9f31-41be-9891-c4086fd146c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@data-value=&quot;Transporte Ferroviário&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
