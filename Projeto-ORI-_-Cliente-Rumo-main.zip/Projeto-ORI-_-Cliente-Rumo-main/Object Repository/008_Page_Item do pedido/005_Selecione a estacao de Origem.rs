<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar na estacao de origem apresentada na lista</description>
   <name>005_Selecione a estacao de Origem</name>
   <tag></tag>
   <elementGuidId>e6fc7afb-7c46-4027-b756-97854c02ce9a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Estação de origem&quot;]//following::ul[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
