<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite escolher o produto na lista após inserir no campo de pesquisa</description>
   <name>009_Escolha do produto na lista apresentada</name>
   <tag></tag>
   <elementGuidId>125ea654-0522-41ad-9cb9-6e4e0bd076c3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@placeholder=&quot;Pesquisar Produtos...&quot;]//following::ul[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
