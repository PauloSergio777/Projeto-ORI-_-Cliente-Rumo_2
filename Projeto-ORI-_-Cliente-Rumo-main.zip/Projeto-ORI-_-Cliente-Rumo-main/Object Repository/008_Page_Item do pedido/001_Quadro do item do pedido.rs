<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento é usado para aguardar a pagina de item de pedido processar com sucesso</description>
   <name>001_Quadro do item do pedido</name>
   <tag></tag>
   <elementGuidId>11ba11ca-c49c-4545-9e9f-33f9cb03b761</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h1[normalize-space(text())='Item do Pedido']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
