<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Este elemento permite apresentar a lista de carteiras no sistema</description>
   <name>008_Selecione a lista de carteira</name>
   <tag></tag>
   <elementGuidId>ea841b73-f384-4238-8236-9e1c1dc1a66b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//*[normalize-space(text())=&quot;Carteira&quot;]//following::div[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
