<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite selecionar o checkbox para ativar a tabela</description>
   <name>002_Selecione o checkbox Ativo</name>
   <tag></tag>
   <elementGuidId>7e75c87f-f29f-41e0-909a-1285e06a6512</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//span[normalize-space(text())='Ativo']//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
