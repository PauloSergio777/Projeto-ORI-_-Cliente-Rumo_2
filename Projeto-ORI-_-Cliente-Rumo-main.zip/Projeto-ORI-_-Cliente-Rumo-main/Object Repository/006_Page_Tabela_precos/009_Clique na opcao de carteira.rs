<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar na opção de carteira do sistema</description>
   <name>009_Clique na opcao de carteira</name>
   <tag></tag>
   <elementGuidId>56887804-8d29-484a-b0eb-ab57742e2643</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[normalize-space(text())=&quot;Grãos&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
