<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite abrir a lista de Tipo de Serviço</description>
   <name>012_Selecione a lista de Tipo de Serviço</name>
   <tag></tag>
   <elementGuidId>ae410b03-e16a-4972-ac10-aff89cb8c5e9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//span[normalize-space(text())=&quot;Tipo de serviço&quot;]//following::div[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
