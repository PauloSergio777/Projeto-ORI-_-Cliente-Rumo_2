<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento clique no da referencia na lista</description>
   <name>005_Clique no ano referencia na lista</name>
   <tag></tag>
   <elementGuidId>33e4cbef-1046-47bd-aa1d-3e1222a596ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[normalize-space(text())='2023']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
