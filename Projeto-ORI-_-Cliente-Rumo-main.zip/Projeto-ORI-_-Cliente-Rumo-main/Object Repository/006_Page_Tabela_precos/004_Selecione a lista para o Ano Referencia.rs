<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite abrir a flag da lista de anos para a referencia</description>
   <name>004_Selecione a lista para o Ano Referencia</name>
   <tag></tag>
   <elementGuidId>ffea244f-aa8d-4381-9252-ad5b9f6456cf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//span[normalize-space(text())='Ano referência']//following::div[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
