<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite localizar o campo na tela</description>
   <name>017_Campo de Informacoes do sistema</name>
   <tag></tag>
   <elementGuidId>3738e12c-f36a-4745-8543-f48c7f7a0780</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[normalize-space(text())=&quot;Informações do sistema&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
