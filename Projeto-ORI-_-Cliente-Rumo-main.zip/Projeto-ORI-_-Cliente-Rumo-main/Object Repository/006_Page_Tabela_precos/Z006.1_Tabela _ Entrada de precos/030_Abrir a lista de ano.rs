<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que abra a lista de ano no quadro</description>
   <name>030_Abrir a lista de ano</name>
   <tag></tag>
   <elementGuidId>d15dd432-5318-486e-8500-c5f4396af277</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//Label[normalize-space(text())=&quot;Ano&quot;]//following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
