<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite selecionar na lista a opcao de escolher a estacao destino</description>
   <name>013_Selecione a primeira opcao na lista</name>
   <tag></tag>
   <elementGuidId>7c4a0a8e-8924-4f91-af49-6ab1c378bcba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Estação destino&quot;]//following::ul[1]/li[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
