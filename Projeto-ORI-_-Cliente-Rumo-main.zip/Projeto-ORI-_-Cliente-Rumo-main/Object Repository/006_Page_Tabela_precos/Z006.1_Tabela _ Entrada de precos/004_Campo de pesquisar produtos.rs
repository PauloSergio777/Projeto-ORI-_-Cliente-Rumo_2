<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite a pesquisa de produtos no sistema</description>
   <name>004_Campo de pesquisar produtos</name>
   <tag></tag>
   <elementGuidId>efd40c93-57a8-46fa-b95a-81505f1f574a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@placeholder=&quot;Pesquisar Produtos…&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
