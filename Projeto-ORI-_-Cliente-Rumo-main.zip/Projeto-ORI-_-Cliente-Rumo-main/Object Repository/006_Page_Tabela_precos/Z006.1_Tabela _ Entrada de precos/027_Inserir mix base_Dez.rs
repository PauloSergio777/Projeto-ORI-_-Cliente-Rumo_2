<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>027_Inserir mix base_Dez</name>
   <tag></tag>
   <elementGuidId>3c6fb564-67ab-4e1d-a5ee-0bbf60e79f10</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Mix base - Dezembro&quot;]//following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
