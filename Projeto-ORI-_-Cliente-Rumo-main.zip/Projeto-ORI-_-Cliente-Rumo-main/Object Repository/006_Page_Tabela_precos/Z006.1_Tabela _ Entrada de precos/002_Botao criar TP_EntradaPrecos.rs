<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite criar a entrada de preços na tabela</description>
   <name>002_Botao criar TP_EntradaPrecos</name>
   <tag></tag>
   <elementGuidId>5813646c-50c2-4be3-8379-6e56e5f571d8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@aria-label=&quot;TP - Entradas de preços|TP - Entradas de preços|Modo de exibição de lista&quot;]//*[normalize-space(text())=&quot;Criar&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
