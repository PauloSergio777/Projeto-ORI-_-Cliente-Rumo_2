<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite salvar o resgitro de entrada de preço criado</description>
   <name>033_Clique em Salvar a Entrada de preco</name>
   <tag></tag>
   <elementGuidId>ede72bb6-a6f4-4db6-ba5c-bce250dcf19c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[normalize-space(text())=&quot;Salvar&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
