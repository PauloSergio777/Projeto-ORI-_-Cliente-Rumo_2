<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>035_Escolha na lista a opcao de praca origem</name>
   <tag></tag>
   <elementGuidId>8d1032f5-fb36-427d-b60b-56280148b03a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Praça origem&quot;]//following::ul[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
