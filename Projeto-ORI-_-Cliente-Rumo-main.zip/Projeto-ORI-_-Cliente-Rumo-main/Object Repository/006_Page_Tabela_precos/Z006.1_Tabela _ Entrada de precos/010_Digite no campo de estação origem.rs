<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite inserir dados no campo estação origem</description>
   <name>010_Digite no campo de estação origem</name>
   <tag></tag>
   <elementGuidId>90a854c5-4cf6-42b3-b135-dbacc8244a58</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Estação origem&quot;]//following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
