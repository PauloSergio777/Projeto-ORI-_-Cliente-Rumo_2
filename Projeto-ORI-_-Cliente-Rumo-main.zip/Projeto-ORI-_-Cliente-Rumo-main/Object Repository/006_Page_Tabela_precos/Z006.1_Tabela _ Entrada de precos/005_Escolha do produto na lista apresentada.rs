<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite escolher o produto na lista após inserir no campo de pesquisa</description>
   <name>005_Escolha do produto na lista apresentada</name>
   <tag></tag>
   <elementGuidId>e132c33f-5977-4ced-b1c8-cc582bb7f828</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//input[@placeholder=&quot;Pesquisar Produtos…&quot;]//following::ul[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
