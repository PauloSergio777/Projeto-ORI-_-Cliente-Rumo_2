<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>037_Escolha na lista a opcao de praca destino</name>
   <tag></tag>
   <elementGuidId>b5accf39-2efe-4b40-9774-13a9ca53eb89</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Praça destino&quot;]//following::ul[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
