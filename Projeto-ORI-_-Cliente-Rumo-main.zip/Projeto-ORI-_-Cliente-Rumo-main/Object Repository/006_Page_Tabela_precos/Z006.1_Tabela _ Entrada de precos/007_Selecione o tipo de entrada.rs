<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento escolhe a opção de serviço no tipo de entrada</description>
   <name>007_Selecione o tipo de entrada</name>
   <tag></tag>
   <elementGuidId>82158064-0418-4174-8dc7-0eadb6e3ae36</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Serviço&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
