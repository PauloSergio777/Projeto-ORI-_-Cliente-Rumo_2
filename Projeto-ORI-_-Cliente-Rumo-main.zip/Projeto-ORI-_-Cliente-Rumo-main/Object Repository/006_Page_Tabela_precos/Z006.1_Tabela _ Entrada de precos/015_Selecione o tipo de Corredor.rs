<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite selecionar o tipo de corredor na lista</description>
   <name>015_Selecione o tipo de Corredor</name>
   <tag></tag>
   <elementGuidId>58b8c469-cc68-43b9-bd44-564a591accd1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[normalize-space(text())=&quot;Malha Central&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
