<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento apresenta a flag de opções para o tipo de entrada</description>
   <name>006_Abrir a lista do tipo de entrada</name>
   <tag></tag>
   <elementGuidId>5643499c-c9f7-4f6f-b83e-94f02022fb6b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@aria-label=&quot;Tipo de entrada, --Nenhum--&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
