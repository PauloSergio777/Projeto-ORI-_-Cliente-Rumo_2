<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar no tipo de serviço apresentado na lista</description>
   <name>009_Selecione o tipo de serviço</name>
   <tag></tag>
   <elementGuidId>1fe9daee-33b5-43b1-894f-c6d917f0ed1c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//lightning-base-combobox-item[@data-value=&quot;Transporte Ferroviário&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
