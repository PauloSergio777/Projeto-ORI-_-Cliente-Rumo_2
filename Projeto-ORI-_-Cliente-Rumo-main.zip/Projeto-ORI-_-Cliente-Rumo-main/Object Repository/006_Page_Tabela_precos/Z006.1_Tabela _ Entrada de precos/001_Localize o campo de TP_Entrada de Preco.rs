<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento localiza o campo de TP-Entrada de Preços</description>
   <name>001_Localize o campo de TP_Entrada de Preco</name>
   <tag></tag>
   <elementGuidId>9faa44f6-ecf1-4e06-8712-571703bc6dfc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@aria-label=&quot;TP - Entradas de preços|TP - Entradas de preços|Modo de exibição de lista&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
