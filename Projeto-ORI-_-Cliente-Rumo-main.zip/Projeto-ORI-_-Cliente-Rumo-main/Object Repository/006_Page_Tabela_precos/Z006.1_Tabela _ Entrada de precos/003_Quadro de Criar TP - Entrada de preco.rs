<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento apresenta o Quadro de Entrada de preço</description>
   <name>003_Quadro de Criar TP - Entrada de preco</name>
   <tag></tag>
   <elementGuidId>27736714-6d07-4f36-b3aa-88e2a72b9f67</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h2[contains(normalize-space(.), &quot;Criar TP - Entrada de preço&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
