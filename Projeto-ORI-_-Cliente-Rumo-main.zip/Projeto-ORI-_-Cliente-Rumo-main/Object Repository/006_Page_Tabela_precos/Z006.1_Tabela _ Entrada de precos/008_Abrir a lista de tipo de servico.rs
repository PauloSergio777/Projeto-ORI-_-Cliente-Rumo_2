<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite abrir a lista de serviço na tela</description>
   <name>008_Abrir a lista de tipo de servico</name>
   <tag></tag>
   <elementGuidId>0c731bdd-7b53-49b4-be88-889c76f4b5aa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@aria-label=&quot;Tipo de serviço, --Nenhum--&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
