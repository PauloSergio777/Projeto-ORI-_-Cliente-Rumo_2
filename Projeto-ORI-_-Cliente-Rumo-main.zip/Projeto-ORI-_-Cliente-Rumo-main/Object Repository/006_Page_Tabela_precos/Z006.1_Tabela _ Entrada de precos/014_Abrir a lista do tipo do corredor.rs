<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite que seja selecionado o tipo de corredor</description>
   <name>014_Abrir a lista do tipo do corredor</name>
   <tag></tag>
   <elementGuidId>67594ea5-ca76-49de-bdde-61268232bcc4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Corredor&quot;]//following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
