<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>020_Inserir mix base_Maio</name>
   <tag></tag>
   <elementGuidId>86ee5907-bdb1-4cf0-83ae-5c40da4142ba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Mix base - Maio&quot;]//following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
