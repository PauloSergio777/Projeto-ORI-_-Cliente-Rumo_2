<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite abrir a lista de tipo de tarifa</description>
   <name>028_Abrir a lista do Tipo de Tarifa</name>
   <tag></tag>
   <elementGuidId>016808ef-f34c-4e9d-83aa-0510cf2afca5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//label[normalize-space(text())=&quot;Tipo tarifa&quot;]//following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
