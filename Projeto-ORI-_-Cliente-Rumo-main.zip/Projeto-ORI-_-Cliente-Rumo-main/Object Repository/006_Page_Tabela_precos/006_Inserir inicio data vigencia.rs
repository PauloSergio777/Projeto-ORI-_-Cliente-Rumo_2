<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir dados no campo de data vigencia</description>
   <name>006_Inserir inicio data vigencia</name>
   <tag></tag>
   <elementGuidId>7c3cd703-4121-491b-984f-340c88c298bc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//span[normalize-space(text())='Vigência início']//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
