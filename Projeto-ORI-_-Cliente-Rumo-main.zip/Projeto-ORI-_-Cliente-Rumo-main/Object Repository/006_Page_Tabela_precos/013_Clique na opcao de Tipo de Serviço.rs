<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>O elemento permite clicar no tipo de serviço</description>
   <name>013_Clique na opcao de Tipo de Serviço</name>
   <tag></tag>
   <elementGuidId>d6919591-5987-4c94-80f9-e477a9f3fa09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@title=&quot;Transporte Ferroviário&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
