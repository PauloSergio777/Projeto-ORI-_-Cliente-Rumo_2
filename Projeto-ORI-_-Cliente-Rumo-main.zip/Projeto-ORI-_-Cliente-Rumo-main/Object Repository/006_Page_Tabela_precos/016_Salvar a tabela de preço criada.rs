<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite salvar a tabela de precos criada</description>
   <name>016_Salvar a tabela de preço criada</name>
   <tag></tag>
   <elementGuidId>dd89ca4a-12cb-4be4-bf67-fd5c549d86c0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionsContainer&quot;]//span[normalize-space(text())='Salvar']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
