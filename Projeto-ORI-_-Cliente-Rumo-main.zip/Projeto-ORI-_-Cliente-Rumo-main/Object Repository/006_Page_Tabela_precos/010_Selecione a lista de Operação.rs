<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite abrir a lista de opção do campo Operação</description>
   <name>010_Selecione a lista de Operação</name>
   <tag></tag>
   <elementGuidId>3aeda9d4-69af-4647-9e01-5d3b1afbfab5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//span[normalize-space(text())=&quot;Operação&quot;]//following::div[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
