<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir dados no campo de nome da tabela de preços.</description>
   <name>001_Nome da Tabela de precos</name>
   <tag></tag>
   <elementGuidId>010fc749-7427-4fb1-9fb0-efea53925ea3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//*[normalize-space(text())='Nome da tabela de preços']//following::input[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
