<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite inserir uma data base na criação da tabela</description>
   <name>003_Inserir Data base</name>
   <tag></tag>
   <elementGuidId>960b072d-4cef-44cd-a4e4-6a20c637219d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//span[normalize-space(text())='Data base']//following::input[1]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
