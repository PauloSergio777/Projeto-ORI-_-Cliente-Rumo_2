<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar em uma opcao de fonte no sistema</description>
   <name>015_Clique na opcao de fonte</name>
   <tag></tag>
   <elementGuidId>07cee7c2-cf07-48fc-95ba-540b3c670d94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@title=&quot;Comercial&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
