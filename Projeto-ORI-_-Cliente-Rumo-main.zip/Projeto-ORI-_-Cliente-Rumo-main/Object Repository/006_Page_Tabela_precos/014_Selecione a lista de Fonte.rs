<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>Esse elemento permite clicar na flag para apresentar a lista de dados Fonte</description>
   <name>014_Selecione a lista de Fonte</name>
   <tag></tag>
   <elementGuidId>f2327b27-5bfd-4ff5-bfe4-8ae6d32d59c6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@class=&quot;actionBody&quot;]//span[normalize-space(text())=&quot;Fonte&quot;]//following::div[2]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
