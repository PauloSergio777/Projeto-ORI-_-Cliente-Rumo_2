<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Esta execução se refere aos cenarios entregues da Fase1 que ja fazem parte do dia a dia do cliente Rumo.</description>
   <name>Rumo_ Cenarios com dados inseridos na planilha</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>fc05f546-0b76-491e-8049-99ccfa6e6aa9</testSuiteGuid>
   <testCaseLink>
      <guid>697678a0-32fe-492e-ae95-b3b8b74edcd7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Rumo_Fase1/001_Rodada de Negociação/001_Criação de tabela de Preços</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>93fa4de1-4e07-47da-8911-9fc3cddd0e8c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Rumo_Fase1/001_Rodada de Negociação/002_Criação de conta</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>46997f75-4ac8-4607-a866-747b4b0210c7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Rumo_Fase1/001_Rodada de Negociação/003_Criação de Contato relacionado na conta</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
   <testCaseLink>
      <guid>7a174777-415e-4734-b66f-67aab6b5d3cc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Rumo_Fase1/001_Rodada de Negociação/004_Criação de Oportunidade e Pedido</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
