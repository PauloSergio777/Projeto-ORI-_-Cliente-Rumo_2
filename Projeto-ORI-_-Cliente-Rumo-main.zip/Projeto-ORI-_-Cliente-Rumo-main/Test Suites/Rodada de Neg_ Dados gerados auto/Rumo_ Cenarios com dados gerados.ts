<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Cernarios totalmente automatico com dados gerados pelo navegador.
Geração de dados Pessoais (Juridicas e Pessoais)
Criação de conta
Criação de contato
Criação de Oportunidade
Criação de Item da Oportunidade
Adição de membro de equipe na oportunidade
Criação de Pedido
Criação de Item do Pedido</description>
   <name>Rumo_ Cenarios com dados gerados</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>082916d6-2e10-46dc-89ce-6224b326ab45</testSuiteGuid>
   <testCaseLink>
      <guid>f2d4ba84-9877-4cca-be24-2665fde2ad55</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Rumo_Fase1/001_Rodada de Negociação/005_CenarioFull</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>18311ed0-f9f7-4429-9734-c016c222ff0e</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>bf1ae2a8-b44e-4221-acfa-cbe3c0d9fa81</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>ac512bf3-c12d-4a1f-acff-0fd3913d94f6</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>9780586f-acc2-49da-8407-135eb8a0e15a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>60f7bc2d-7ea9-43b3-97de-87caa6496608</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>7092961b-239d-4e75-9177-9098ad313f69</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>f686576c-dfb9-4708-9fd5-83440e8d2526</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>10c86308-a495-480b-bcaf-24bf711541cc</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>a206d631-f8da-4e4f-91ca-283cd60808ae</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Rumo_Fase1/001_Rodada de Negociação/005_CenarioFull</testCaseId>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>18311ed0-f9f7-4429-9734-c016c222ff0e</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>bf1ae2a8-b44e-4221-acfa-cbe3c0d9fa81</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>ac512bf3-c12d-4a1f-acff-0fd3913d94f6</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>9780586f-acc2-49da-8407-135eb8a0e15a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>60f7bc2d-7ea9-43b3-97de-87caa6496608</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>7092961b-239d-4e75-9177-9098ad313f69</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>f686576c-dfb9-4708-9fd5-83440e8d2526</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>10c86308-a495-480b-bcaf-24bf711541cc</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
