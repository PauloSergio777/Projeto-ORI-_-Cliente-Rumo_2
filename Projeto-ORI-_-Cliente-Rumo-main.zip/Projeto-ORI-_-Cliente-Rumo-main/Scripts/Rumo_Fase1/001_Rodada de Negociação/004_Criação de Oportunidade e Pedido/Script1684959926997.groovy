import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'Abrir o navegador com a pagina inicial do SF'
WebUI.openBrowser(GlobalVariable.UrlDEV)

'Maximizar a tela do navegador'
WebUI.maximizeWindow()

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('001_Page_Login Salesforce/001_Imagem da tela de login'), 30)

'Inserir o usuario de acesso ao sistema '
WebUI.setText(findTestObject('001_Page_Login Salesforce/002_Usuario de acesso'), GlobalVariable.UsuarioDEV)

'Inserir a senha de acesso ao sistema'
WebUI.setText(findTestObject('001_Page_Login Salesforce/003_ Senha de acesso'), GlobalVariable.SenhaDEV)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Fazer login no sistema'
WebUI.click(findTestObject('001_Page_Login Salesforce/004_Botão de login_'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('002_Page_Home Salesforce/001_Quadro de desempenho da tela inicial do SF'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no iniciador de aplicativos "9 Bolinhas da tela inicial"'
WebUI.click(findTestObject('002_Page_Home Salesforce/002_Botão para menu de iniciador de aplicativos'))

'Digite no campo o objeto que devera ser acesso no sistema'
WebUI.setText(findTestObject('002_Page_Home Salesforce/003_Campo para pesquisa de aplicativos no SF'), 'Contas')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Selecione o objeto que foi digitado na busca '
WebUI.click(findTestObject('002_Page_Home Salesforce/004_Resultado APLICATIVOS na lista de iniciador de Aplicativos'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/001_Processamento da lista de contas'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Selecione os filtros disponiveis no sistema'
WebUI.click(findTestObject('003_Page_Account/002_Filtro de relação de conta'))

'Digite o filtro de todas as contas '
WebUI.setText(findTestObject('003_Page_Account/003_Pesquisa de filtros na lista'), 'Todas as Contas')

'Selecione o tipo de filtro para todas as contas digitado anteriormente\r\n'
WebUI.click(findTestObject('003_Page_Account/004_Seleção da opção de Todas as contas'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/001_Processamento da lista de contas'), 30)

'Inserir o nome da conta no campo de pesquisa'
WebUI.setText(findTestObject('003_Page_Account/005_Pesquisa de contas na lista'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        1, 2))

'Clique em um campo da tela para processamento \r\n'
WebUI.click(findTestObject('003_Page_Account/001_Processamento da lista de contas'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na conta localizada'
WebUI.click(findTestObject('003_Page_Account/006_Escolha da conta'))

WebUI.deleteAllCookies()

'Aguarde o processamento da pagina da conta\r\n'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/027_Valide a presenca do campo Informacoes de Conta'), 30)

WebUI.refresh()

'Aguarde o processamento da pagina da conta\r\n'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/027_Valide a presenca do campo Informacoes de Conta'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na opção de Nova Oportunidade'
WebUI.click(findTestObject('003_Page_Account/010_Nova Oportunidade na conta'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('004_Page_Account_NewOpportunity/001_Quadro Aberto de nova oportunidade'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Inserir uma data no campo'
WebUI.setText(findTestObject('004_Page_Account_NewOpportunity/002_Data prevista de fechamento'), '02/12/2023')

'Inserir uma data no campo'
WebUI.setText(findTestObject('004_Page_Account_NewOpportunity/003_Inicio da execucao'), '02/03/2023')

'Inserir uma data no campo'
WebUI.setText(findTestObject('004_Page_Account_NewOpportunity/004_Fim da execucao'), '01/12/2023')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na lista de opções de carteiras que sera exibida'
WebUI.scrollToElement(findTestObject('005_Page_Opportunity/021_Clique para exibir a lista de Carteiras na criação da Oportunidade'), 
    30)

'Clique na opção presente na lista'
WebUI.waitForElementClickable(findTestObject('005_Page_Opportunity/021_Clique para exibir a lista de Carteiras na criação da Oportunidade'), 
    30)

'Clique na lista de opções de carteiras que sera exibida'
WebUI.click(findTestObject('005_Page_Opportunity/021_Clique para exibir a lista de Carteiras na criação da Oportunidade'))

'Clique na opção presente na lista'
WebUI.click(findTestObject('005_Page_Opportunity/022_Selecione o tipo na lista de carteira'))

WebUI.scrollToElement(findTestObject('005_Page_Opportunity/023_Clique para exibir a lista de Operação na oportunidade'), 
    30)

'Clique na lista de opções de operação que sera exibida'
WebUI.click(findTestObject('005_Page_Opportunity/023_Clique para exibir a lista de Operação na oportunidade'))

'Clique na opção presente na lista'
WebUI.click(findTestObject('005_Page_Opportunity/024_selecione o tipo na lista de operacao apresentada'))

WebUI.scrollToElement(findTestObject('004_Page_Account_NewOpportunity/005_Corredor disponiveis'), 30)

'Selecione um valor do quadro de corredor '
WebUI.click(findTestObject('004_Page_Account_NewOpportunity/005_Corredor disponiveis'))

'Move para escolhidos o valor selecionado '
WebUI.click(findTestObject('004_Page_Account_NewOpportunity/006_Mover para escolhidos'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Salvar a nova oportunidade'
WebUI.click(findTestObject('004_Page_Account_NewOpportunity/007_Salvar a nova oportunidade'))

WebUI.deleteAllCookies(FailureHandling.STOP_ON_FAILURE)

'Aguarde o carregamento da tela '
WebUI.waitForElementClickable(findTestObject('005_Page_Opportunity/001_Adicionar Membro da equipe da oportunidade'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Adicionar o Membro de equipe de oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/001_Adicionar Membro da equipe da oportunidade'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('005_Page_Opportunity/002_Quadro de Adicionar Membros da equipe da oportunidade'), 
    30)

'Clique no campo para selecionar o acesso a oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/003_Clique para selecao de Acesso de Oportunidade'))

'Clique no campo para selecionar o acesso a oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/003_Clique para selecao de Acesso de Oportunidade'))

'Selecione a opção de Leitura e Gravação de tela'
WebUI.click(findTestObject('005_Page_Opportunity/004_Selecao da Leitura_Gravacao de acesso a oportunidade'))

'Clique para abrir as opções de papel na equipe'
WebUI.click(findTestObject('005_Page_Opportunity/007_Clique no Papel da Equipe'))

WebUI.delay(2)

'Clique para selecionar o usuario na lista'
WebUI.click(findTestObject('005_Page_Opportunity/005_2_Botao para selecionar o usuario'), FailureHandling.STOP_ON_FAILURE)

WebUI.setText(findTestObject('005_Page_Opportunity/005_Digite o nome no campo selecao de usuario'), 'Paulo Silva')

WebUI.delay(2)

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('005_Page_Opportunity/006_Seleciona o usuario'), 30)

'Selecione o Usuario na lista apresentada\r\n'
WebUI.click(findTestObject('005_Page_Opportunity/006_Seleciona o usuario'))

'Clique para abrir as opções de papel na equipe'
WebUI.click(findTestObject('005_Page_Opportunity/007_Clique no Papel da Equipe'))

'Clique para abrir as opções de papel na equipe'
WebUI.click(findTestObject('005_Page_Opportunity/007_Clique no Papel da Equipe'))

'Selecione o papel da equipe Executivo de Vendas'
WebUI.click(findTestObject('005_Page_Opportunity/008_Seleciona na lista o papel da equipe'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Salvar para processo de novo membro\r\n'
WebUI.click(findTestObject('005_Page_Opportunity/009_Clique em salvar para inserir o membro'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('005_Page_Opportunity/001_Adicionar Membro da equipe da oportunidade'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no botão de novo item da oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/010_Clique do novo item da oportunidade'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('005_Page_Opportunity/011_Quadro de Novo item da Oportunidade'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Inserir um produto para pesquisa '
WebUI.setText(findTestObject('005_Page_Opportunity/012_Inserir produto a ser pesquisado'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        12, 2))

'Aguarde que o elemento de escolha fique visivel para clique'
WebUI.waitForElementClickable(findTestObject('005_Page_Opportunity/013_Clique no resultado do produto localizado'), 30)

'Clique no produto localizado após escrita'
WebUI.click(findTestObject('005_Page_Opportunity/013_Clique no resultado do produto localizado'))

'Clique para exibir a lista de tipos de serviços'
WebUI.click(findTestObject('005_Page_Opportunity/014_Clique na lista de Tipo de Serviço'))

'Selecione um valor do item de tipo de serviço na lista'
WebUI.click(findTestObject('005_Page_Opportunity/015_Selecione o tipo de serviço na lista'))

WebUI.delay(2)

'Digite no campo a estacao origem '
WebUI.setText(findTestObject('005_Page_Opportunity/025_Campo de insercao da estacao O'), 'QA ORIGEM')

'Selecione a estação de origem'
WebUI.click(findTestObject('005_Page_Opportunity/026_Selecione a estacao O'))

'Digite no campo a estacao origem '
WebUI.setText(findTestObject('005_Page_Opportunity/027_Campo de insercao da estacao D'), 'QA DESTINO')

'Selecione a estação de origem'
WebUI.click(findTestObject('005_Page_Opportunity/028_Selecione a estacao D'))

'Inserir um valor no campo volume total'
WebUI.setText(findTestObject('005_Page_Opportunity/018_Inserir um valor no campo de Volume Total'), '100')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Salvar o item com sucesso.'
WebUI.click(findTestObject('005_Page_Opportunity/019_Clique em salvar apresentado no quadro'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na opção de novo pedido na tela da oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/020_Clique em novo pedido na tela'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Rolar a tela para a presença do campo'
WebUI.scrollToElement(findTestObject('007_Page_Pedidos/001_Numero do Pedido'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Rolar a tela para a presença do campo'
WebUI.scrollToElement(findTestObject('007_Page_Pedidos/002_Campo da Tabela de precos'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no botão de novo item do pedido'
WebUI.click(findTestObject('007_Page_Pedidos/003_Novo item do pedido'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('008_Page_Item do pedido/001_Quadro do item do pedido'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na flag de tipo de serviço'
WebUI.click(findTestObject('008_Page_Item do pedido/002_Expandir a lista de Tipo de Serviço'))

'Selecione o tipo do serviço na lista'
WebUI.click(findTestObject('008_Page_Item do pedido/003_Selecione o tipo de serviço'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('008_Page_Item do pedido/004_Digite no campo de estação origem'), 30)

'Digite no campo a estacao origem '
WebUI.setText(findTestObject('008_Page_Item do pedido/004_Digite no campo de estação origem'), 'QA ORIGEM')

'Selecione a estação de origem'
WebUI.click(findTestObject('008_Page_Item do pedido/005_Selecione a estacao de Origem'))

'Digite no campo de estação de destino'
WebUI.setText(findTestObject('008_Page_Item do pedido/006_Digite no campo estação de Destino'), 'QA DESTINO')

'Selecione no campo de estação de destino'
WebUI.click(findTestObject('008_Page_Item do pedido/007_ Selecione a estacao destino'))

'Inserir um produto no campo de Produto'
WebUI.setText(findTestObject('008_Page_Item do pedido/008_Campo de pesquisar produtos'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        12, 2))

'Clica na opção que será apresantada'
WebUI.waitForElementClickable(findTestObject('008_Page_Item do pedido/009_Escolha do produto na lista apresentada'), 30)

'Clica na opção que será apresantada'
WebUI.click(findTestObject('008_Page_Item do pedido/009_Escolha do produto na lista apresentada'))

WebUI.scrollToElement(findTestObject('008_Page_Item do pedido/010_Abrir a lista de ano'), 30)

'Clique na flag de ano '
WebUI.click(findTestObject('008_Page_Item do pedido/010_Abrir a lista de ano'))

'Selecione o ano na lista'
WebUI.click(findTestObject('008_Page_Item do pedido/011_Selecione o ano'))

'Inserir um registro no campo volume do mês'
WebUI.setText(findTestObject('008_Page_Item do pedido/012_Inserir dados numerico na lista de volume'), '100')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique para salvar o item com sucesso'
WebUI.click(findTestObject('008_Page_Item do pedido/013_Clique para salvar o item com sucesso'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('008_Page_Item do pedido/014_Elemento Preço Base'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

WebUI.scrollToElement(findTestObject('008_Page_Item do pedido/014_Elemento Preço Base'), 30)

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('008_Page_Item do pedido/015_Elemento Contraproposta'), 30)

'Clique na flag da lista de contra proposta'
WebUI.click(findTestObject('008_Page_Item do pedido/015_Elemento Contraproposta'), FailureHandling.STOP_ON_FAILURE)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

