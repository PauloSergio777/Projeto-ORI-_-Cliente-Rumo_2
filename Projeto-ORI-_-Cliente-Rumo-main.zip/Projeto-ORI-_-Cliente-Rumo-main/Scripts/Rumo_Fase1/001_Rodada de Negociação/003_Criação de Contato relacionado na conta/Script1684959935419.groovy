import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'Abrir o navegador com a pagina inicial do SF'
WebUI.openBrowser(GlobalVariable.UrlDEV)

'Maximizar a tela do navegador'
WebUI.maximizeWindow()

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('001_Page_Login Salesforce/001_Imagem da tela de login'), 30)

'Inserir o usuario de acesso ao sistema '
WebUI.setText(findTestObject('001_Page_Login Salesforce/002_Usuario de acesso'), GlobalVariable.UsuarioDEV)

'Inserir a senha de acesso ao sistema'
WebUI.setText(findTestObject('001_Page_Login Salesforce/003_ Senha de acesso'), GlobalVariable.SenhaDEV)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Fazer login no sistema'
WebUI.click(findTestObject('001_Page_Login Salesforce/004_Botão de login_'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('002_Page_Home Salesforce/001_Quadro de desempenho da tela inicial do SF'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no iniciador de aplicativos "9 Bolinhas da tela inicial"'
WebUI.click(findTestObject('002_Page_Home Salesforce/002_Botão para menu de iniciador de aplicativos'))

'Digite no campo o objeto que devera ser acesso no sistema'
WebUI.setText(findTestObject('002_Page_Home Salesforce/003_Campo para pesquisa de aplicativos no SF'), 'Contas')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Selecione o objeto que foi digitado na busca '
WebUI.click(findTestObject('002_Page_Home Salesforce/004_Resultado APLICATIVOS na lista de iniciador de Aplicativos'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/001_Processamento da lista de contas'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Selecione os filtros disponiveis no sistema'
WebUI.click(findTestObject('003_Page_Account/002_Filtro de relação de conta'))

'Digite o filtro de todas as contas '
WebUI.setText(findTestObject('003_Page_Account/003_Pesquisa de filtros na lista'), 'Todas as Contas')

'Selecione o tipo de filtro para todas as contas digitado anteriormente\r\n'
WebUI.click(findTestObject('003_Page_Account/004_Seleção da opção de Todas as contas'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/001_Processamento da lista de contas'), 30)

'Inserir o nome da conta no campo de pesquisa'
WebUI.setText(findTestObject('003_Page_Account/005_Pesquisa de contas na lista'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        1, 2))

'Clique em um campo da tela para processamento \r\n'
WebUI.click(findTestObject('003_Page_Account/001_Processamento da lista de contas'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na conta localizada'
WebUI.click(findTestObject('003_Page_Account/006_Escolha da conta'))

WebUI.deleteAllCookies()

'Aguarde o processamento da pagina da conta\r\n'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/027_Valide a presenca do campo Informacoes de Conta'), 30)

WebUI.refresh()

'Aguarde o processamento da pagina da conta\r\n'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/027_Valide a presenca do campo Informacoes de Conta'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na opção de criar um novo contato'
WebUI.click(findTestObject('003_Page_Account/031_Botao de Criar novo Contato'))

'Aguarde o processamento da pagina\r\n'
WebUI.waitForElementVisible(findTestObject('009_Page_Contacts/001_Valida o quadro de Criar contato'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Digite o primeiro nome no campo'
WebUI.setText(findTestObject('009_Page_Contacts/002_Campo de insercao do primeiro nome'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        16, 2))

'Digite o sobrenome no campo'
WebUI.setText(findTestObject('009_Page_Contacts/003_Campo de insercao do Sobrenome'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        17, 2))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Digite a data de nascimento no campo'
WebUI.setText(findTestObject('009_Page_Contacts/004_Campo de insercao da data de nascimento'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        18, 2))

'Digite o email no campo'
WebUI.setText(findTestObject('009_Page_Contacts/005_Campo de insercao do email'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        19, 2))

WebUI.delay(2)

'Digite o email no campo'
WebUI.scrollToElement(findTestObject('009_Page_Contacts/005_Campo de insercao do email'), 10)

'Digite o email no campo'
WebUI.click(findTestObject('009_Page_Contacts/008_Campo de insercao do Telefone Cel'), FailureHandling.STOP_ON_FAILURE)

'Clique na flag de opcoes do campo Funcoes'
WebUI.click(findTestObject('009_Page_Contacts/006_Lista de opcoes da Funcao'))

WebUI.delay(2)

'Selecione na lista um tipo de funcao'
WebUI.click(findTestObject('009_Page_Contacts/007_Selecione na lista de Funcao'))

'Digite o email no campo'
WebUI.setText(findTestObject('009_Page_Contacts/008_Campo de insercao do Telefone Cel'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        20, 2))

'Clique na flag de opcoes do campo Departamento'
WebUI.click(findTestObject('009_Page_Contacts/009_Lista de opcoes de Departamento'))

WebUI.delay(2)

'Selecione na lista um tipo de Departamento'
WebUI.click(findTestObject('009_Page_Contacts/010_Selecione na lista de Departamento'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Localize na tela o campo de informações adicionais'
WebUI.scrollToElement(findTestObject('009_Page_Contacts/011_Quadro de informacoes adicionais'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em um item da lista carteira'
WebUI.click(findTestObject('009_Page_Contacts/012_Selecione na lista o tipo de Carteira'))

WebUI.delay(2)

'Clique enviar o item a lista de escolhidos da carteira'
WebUI.click(findTestObject('009_Page_Contacts/013_Clique para a inserir na lista de escolhidos da carteira'))

WebUI.delay(2)

'Clique em um item da lista Corredor'
WebUI.click(findTestObject('009_Page_Contacts/014_Selecione na lista o tipo de Corredor'))

WebUI.delay(2)

'Clique enviar o item a lista de escolhidos do corredor'
WebUI.click(findTestObject('009_Page_Contacts/015_Clique para inserir na lista de escolhidos do tipo de Corredor'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique para salvar o processamento da criação'
WebUI.click(findTestObject('009_Page_Contacts/016_Botão para salvar a criacao do contato'))

'Aguarde o processamento da pagina\r\n'
WebUI.waitForElementVisible(findTestObject('009_Page_Contacts/017_Campo de relacionado após salvamento'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

