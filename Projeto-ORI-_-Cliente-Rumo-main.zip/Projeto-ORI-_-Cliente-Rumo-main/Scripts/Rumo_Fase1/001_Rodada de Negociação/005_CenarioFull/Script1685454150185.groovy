import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'Abrir o navegador de busca na pagina de gerador de empresas'
WebUI.openBrowser(GlobalVariable.GeraEmpresa)

WebUI.maximizeWindow()

'Aguarde o elemento ficar disponivel a clique'
WebUI.waitForElementVisible(findTestObject('011_Gerador_Empresas/002_Botao de Gerar Empresa'), 10)

'Clique no botao de Gerar Empresa'
WebUI.click(findTestObject('011_Gerador_Empresas/002_Botao de Gerar Empresa'))

WebUI.delay(2)

'Colete os dados do campo'
NomeEmpresa = WebUI.getText(findTestObject('011_Gerador_Empresas/003_Captura do campo Nome', [('variable') : NomeEmpresa]))

System.out.println(NomeEmpresa)

'Colete os dados do campo'
CNPJ = WebUI.getText(findTestObject('011_Gerador_Empresas/004_Captura do campo CNPJ', [('variable') : CNPJ]))

System.out.println(CNPJ)

'Colete os dados do campo'
IEstadual = WebUI.getText(findTestObject('011_Gerador_Empresas/005_Captura do campo Inscricao Estadual', [('variable') : IEstadual]))

System.out.println(IEstadual)

'Colete os dados do campo'
EmailEmpresarial = WebUI.getText(findTestObject('011_Gerador_Empresas/006_Captura do campo de email Empresarial', [('variable') : EmailEmpresarial]))

System.out.println(EmailEmpresarial)

'Abrir o navegador com a pagina de gerador de pessoas'
WebUI.navigateToUrl(GlobalVariable.GeraPessoa)

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('012_Gerador de Pessoas/001_Botao de Gerar Pessoa'), 10)

'Aguarde a pagina ser carregada com sucesso'
WebUI.click(findTestObject('012_Gerador de Pessoas/001_Botao de Gerar Pessoa'), FailureHandling.STOP_ON_FAILURE)

WebUI.delay(2)

'Colte o nome Gerado no campo de nome'
NomePessoal = WebUI.getText(findTestObject('012_Gerador de Pessoas/002_Campo de Nome da pessoa', [('variable') : NomePessoal]), 
    FailureHandling.STOP_ON_FAILURE)

System.out.println(NomePessoal)

'Colete a data de nascimento gerada'
DataNascimento = WebUI.getText(findTestObject('012_Gerador de Pessoas/003_Campo de Data Nascimento', [('variable') : DataNascimento]), 
    FailureHandling.STOP_ON_FAILURE)

System.out.println(DataNascimento)

'Colete a data do telefone gerado'
TelefonePessoal = WebUI.getText(findTestObject('012_Gerador de Pessoas/004_Campo de telefone cel pessoal', [('variable') : TelefonePessoal]), 
    FailureHandling.STOP_ON_FAILURE)

System.out.println(TelefonePessoal)

'Colete o email gerado'
EmailPessoal = WebUI.getText(findTestObject('012_Gerador de Pessoas/005_Campo de Email Pessoal', [('variable') : EmailPessoal]), 
    FailureHandling.STOP_ON_FAILURE)

System.out.println(EmailPessoal)

WebUI.closeBrowser()

'Abrir o navegador com a pagina inicial do SF'
WebUI.openBrowser(GlobalVariable.UrlDEV)

'Maximizar a tela do navegador'
WebUI.maximizeWindow()

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('001_Page_Login Salesforce/001_Imagem da tela de login'), 10)

'Inserir o usuario de acesso ao sistema '
WebUI.setText(findTestObject('001_Page_Login Salesforce/002_Usuario de acesso'), GlobalVariable.UsuarioDEV)

'Inserir a senha de acesso ao sistema'
WebUI.setText(findTestObject('001_Page_Login Salesforce/003_ Senha de acesso'), GlobalVariable.SenhaDEV)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Fazer login no sistema'
WebUI.click(findTestObject('001_Page_Login Salesforce/004_Botão de login_'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('002_Page_Home Salesforce/001_Quadro de desempenho da tela inicial do SF'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no iniciador de aplicativos "9 Bolinhas da tela inicial"'
WebUI.click(findTestObject('002_Page_Home Salesforce/002_Botão para menu de iniciador de aplicativos'))

'Digite no campo o objeto que devera ser acesso no sistema'
WebUI.setText(findTestObject('002_Page_Home Salesforce/003_Campo para pesquisa de aplicativos no SF'), 'Contas')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Selecione o objeto que foi digitado na busca '
WebUI.click(findTestObject('002_Page_Home Salesforce/004_Resultado APLICATIVOS na lista de iniciador de Aplicativos'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/001_Processamento da lista de contas'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Na tela da lista de contas selecione o botão de Criar'
WebUI.click(findTestObject('003_Page_Account/011_Clique do botão Criar'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/012_Selecione o tipo do registro de conta'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na escolha do tipo de Conta'
WebUI.click(findTestObject('003_Page_Account/012_Selecione o tipo do registro de conta'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em avançar após escolha do tipo'
WebUI.click(findTestObject('003_Page_Account/013_Clique de Avançar na tela de Nova Conta'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/014_Quadro de inserção de dados Nova Conta'), 10)

'Inserir um nome de conta no quadro'
WebUI.setText(findTestObject('003_Page_Account/015_Inserção de dados no campo nome da conta'), NomeEmpresa)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

WebUI.click(findTestObject('003_Page_Account/018_Campo de insercao de CNPJ'))

'Clique para apresentar a lista de opções em Status'
WebUI.click(findTestObject('003_Page_Account/016_Abrir a flag de opcoes de status'))

'Clique em novo na lista de status'
WebUI.click(findTestObject('003_Page_Account/017_Selecione o novo de status'))

'Inserir CPNJ capturado na geracao'
WebUI.click(findTestObject('003_Page_Account/018_Campo de insercao de CNPJ'), FailureHandling.STOP_ON_FAILURE)

'Inserir CPNJ capturado na geracao'
WebUI.setText(findTestObject('003_Page_Account/018_Campo de insercao de CNPJ'), CNPJ)

'Inserir dados no campo Razao Social'
WebUI.click(findTestObject('003_Page_Account/019_Inserção de dados da Razao Social'), FailureHandling.STOP_ON_FAILURE)

'Inserir dados no campo Razao Social'
WebUI.setText(findTestObject('003_Page_Account/019_Inserção de dados da Razao Social'), NomeEmpresa)

'Inserir dados no campo Inscrição estadual'
WebUI.click(findTestObject('003_Page_Account/020_Inserir dados no campo Inscricao Estadual'), FailureHandling.STOP_ON_FAILURE)

'Inserir dados no campo Inscrição estadual'
WebUI.setText(findTestObject('003_Page_Account/020_Inserir dados no campo Inscricao Estadual'), IEstadual)

'Inserir dados no campo de Ramo de Atividade'
WebUI.click(findTestObject('003_Page_Account/021_Inserção de dados no campo Ramo de Atividade'), FailureHandling.STOP_ON_FAILURE)

'Inserir dados no campo de Ramo de Atividade'
WebUI.setText(findTestObject('003_Page_Account/021_Inserção de dados no campo Ramo de Atividade'), 'Automation QA')

'Clique para apresentar a lista de opções em Origem'
WebUI.click(findTestObject('003_Page_Account/022_Abrir a Flag de opcoes de origem'))

'Clique na opção de eventos na lista apresentada'
WebUI.click(findTestObject('003_Page_Account/023_Selecione Eventos na flag de origem'))

'Inserir um email no campo E-mail para envio NFE'
WebUI.setText(findTestObject('003_Page_Account/024_inserção de dados no campo E-mail para envio NFE'), EmailEmpresarial)

'Inserir um email no campo E-mail para envio CTE'
WebUI.setText(findTestObject('003_Page_Account/025_inserção de dados no campo E-mail para envio CTE'), EmailEmpresarial)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Avançar após inserir os dados da nova conta'
WebUI.click(findTestObject('003_Page_Account/026_Clique Salvar Conta'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/027_Valide a presenca do campo Informacoes de Conta'), 10)

WebUI.deleteAllCookies()

WebUI.refresh()

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/027_Valide a presenca do campo Informacoes de Conta'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na opção de criar um novo contato'
WebUI.click(findTestObject('003_Page_Account/031_Botao de Criar novo Contato'))

'Aguarde o processamento da pagina\r\n'
WebUI.waitForElementVisible(findTestObject('009_Page_Contacts/001_Valida o quadro de Criar contato'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Digite o primeiro nome no campo'
WebUI.setText(findTestObject('009_Page_Contacts/002_Campo de insercao do primeiro nome'), NomePessoal)

'Digite o sobrenome no campo'
WebUI.setText(findTestObject('009_Page_Contacts/003_Campo de insercao do Sobrenome'), 'QA Auto')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

WebUI.scrollToElement(findTestObject('009_Page_Contacts/004_Campo de insercao da data de nascimento'), 15)

'Digite a data de nascimento no campo'
WebUI.click(findTestObject('009_Page_Contacts/004_Campo de insercao da data de nascimento'), FailureHandling.STOP_ON_FAILURE)

'Digite a data de nascimento no campo'
WebUI.setText(findTestObject('009_Page_Contacts/004_Campo de insercao da data de nascimento'), DataNascimento)

'Digite o email no campo'
WebUI.setText(findTestObject('009_Page_Contacts/005_Campo de insercao do email'), EmailPessoal)

WebUI.delay(2)

'Clique na flag de opcoes do campo Funcoes'
WebUI.click(findTestObject('009_Page_Contacts/006_Lista de opcoes da Funcao'))

'clique no campo'
WebUI.click(findTestObject('009_Page_Contacts/018_Campo do contato'))

'Clique na flag de opcoes do campo Funcoes'
WebUI.click(findTestObject('009_Page_Contacts/006_Lista de opcoes da Funcao'))

WebUI.delay(2)

'Selecione na lista um tipo de funcao'
WebUI.click(findTestObject('009_Page_Contacts/007_Selecione na lista de Funcao'))

'clique no campo'
WebUI.click(findTestObject('009_Page_Contacts/018_Campo do contato'))

'Digite o telefone no campo'
WebUI.setText(findTestObject('009_Page_Contacts/008_Campo de insercao do Telefone Cel'), TelefonePessoal)

'Clique na flag de opcoes do campo Departamento'
WebUI.click(findTestObject('009_Page_Contacts/009_Lista de opcoes de Departamento'))

WebUI.delay(2)

'Selecione na lista um tipo de Departamento'
WebUI.click(findTestObject('009_Page_Contacts/010_Selecione na lista de Departamento'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Localize na tela o campo de informações adicionais'
WebUI.scrollToElement(findTestObject('009_Page_Contacts/011_Quadro de informacoes adicionais'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em um item da lista carteira'
WebUI.click(findTestObject('009_Page_Contacts/012_Selecione na lista o tipo de Carteira'))

WebUI.delay(2)

'Clique enviar o item a lista de escolhidos da carteira'
WebUI.click(findTestObject('009_Page_Contacts/013_Clique para a inserir na lista de escolhidos da carteira'))

WebUI.delay(2)

'Clique em um item da lista Corredor'
WebUI.click(findTestObject('009_Page_Contacts/014_Selecione na lista o tipo de Corredor'))

WebUI.delay(2)

'Clique enviar o item a lista de escolhidos do corredor'
WebUI.click(findTestObject('009_Page_Contacts/015_Clique para inserir na lista de escolhidos do tipo de Corredor'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique para salvar o processamento da criação'
WebUI.click(findTestObject('009_Page_Contacts/016_Botão para salvar a criacao do contato'))

'Aguarde o processamento da pagina\r\n'
WebUI.waitForElementVisible(findTestObject('009_Page_Contacts/017_Campo de relacionado após salvamento'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na opção de Nova Oportunidade'
WebUI.click(findTestObject('003_Page_Account/010_Nova Oportunidade na conta'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('004_Page_Account_NewOpportunity/001_Quadro Aberto de nova oportunidade'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Inserir uma data no campo'
WebUI.setText(findTestObject('004_Page_Account_NewOpportunity/002_Data prevista de fechamento'), '02/12/2023')

'Inserir uma data no campo'
WebUI.setText(findTestObject('004_Page_Account_NewOpportunity/003_Inicio da execucao'), '02/03/2023')

'Inserir uma data no campo'
WebUI.setText(findTestObject('004_Page_Account_NewOpportunity/004_Fim da execucao'), '01/12/2023')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na lista de opções de carteiras que sera exibida'
WebUI.scrollToElement(findTestObject('005_Page_Opportunity/021_Clique para exibir a lista de Carteiras na criação da Oportunidade'), 
    30)

'Clique na opção presente na lista'
WebUI.waitForElementClickable(findTestObject('005_Page_Opportunity/021_Clique para exibir a lista de Carteiras na criação da Oportunidade'), 
    10)

'Clique na lista de opções de carteiras que sera exibida'
WebUI.click(findTestObject('005_Page_Opportunity/021_Clique para exibir a lista de Carteiras na criação da Oportunidade'))

'Clique na opção Grãos presente na lista'
WebUI.click(findTestObject('005_Page_Opportunity/022_01_Selecione Grãos no tipo da lista de carteira'))

WebUI.scrollToElement(findTestObject('005_Page_Opportunity/023_Clique para exibir a lista de Operação na oportunidade'), 
    30)

'Clique na lista de opções de operação que sera exibida'
WebUI.click(findTestObject('005_Page_Opportunity/023_Clique para exibir a lista de Operação na oportunidade'))

'Clique na opção presente na lista'
WebUI.click(findTestObject('005_Page_Opportunity/024_selecione o tipo na lista de operacao apresentada'))

WebUI.scrollToElement(findTestObject('004_Page_Account_NewOpportunity/005_Corredor disponiveis'), 30)

'Selecione um valor do quadro de corredor '
WebUI.click(findTestObject('004_Page_Account_NewOpportunity/005_Corredor disponiveis'))

'Move para escolhidos o valor selecionado '
WebUI.click(findTestObject('004_Page_Account_NewOpportunity/006_Mover para escolhidos'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Salvar a nova oportunidade'
WebUI.click(findTestObject('004_Page_Account_NewOpportunity/007_Salvar a nova oportunidade'))

WebUI.deleteAllCookies(FailureHandling.STOP_ON_FAILURE)

'Aguarde o carregamento da tela '
WebUI.waitForElementClickable(findTestObject('005_Page_Opportunity/001_Adicionar Membro da equipe da oportunidade'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Adicionar o Membro de equipe de oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/001_Adicionar Membro da equipe da oportunidade'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('005_Page_Opportunity/002_Quadro de Adicionar Membros da equipe da oportunidade'), 
    10)

'Clique no campo para selecionar o acesso a oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/003_Clique para selecao de Acesso de Oportunidade'))

'Clique no campo para selecionar o acesso a oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/003_Clique para selecao de Acesso de Oportunidade'))

'Selecione a opção de Leitura e Gravação de tela'
WebUI.click(findTestObject('005_Page_Opportunity/004_Selecao da Leitura_Gravacao de acesso a oportunidade'))

'Clique para abrir as opções de papel na equipe'
WebUI.click(findTestObject('005_Page_Opportunity/007_Clique no Papel da Equipe'))

WebUI.delay(2)

'Clique para selecionar o usuario na lista'
WebUI.click(findTestObject('005_Page_Opportunity/005_2_Botao para selecionar o usuario'), FailureHandling.STOP_ON_FAILURE)

WebUI.setText(findTestObject('005_Page_Opportunity/005_Digite o nome no campo selecao de usuario'), 'Paulo Silva')

WebUI.delay(2)

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('005_Page_Opportunity/006_Seleciona o usuario'), 10)

'Selecione o Usuario na lista apresentada\r\n'
WebUI.click(findTestObject('005_Page_Opportunity/006_Seleciona o usuario'))

'Clique para abrir as opções de papel na equipe'
WebUI.click(findTestObject('005_Page_Opportunity/007_Clique no Papel da Equipe'))

'Clique para abrir as opções de papel na equipe'
WebUI.click(findTestObject('005_Page_Opportunity/007_Clique no Papel da Equipe'))

'Selecione o papel da equipe Executivo de Vendas'
WebUI.click(findTestObject('005_Page_Opportunity/008_Seleciona na lista o papel da equipe'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Salvar para processo de novo membro\r\n'
WebUI.click(findTestObject('005_Page_Opportunity/009_Clique em salvar para inserir o membro'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('005_Page_Opportunity/001_Adicionar Membro da equipe da oportunidade'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no botão de novo item da oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/010_Clique do novo item da oportunidade'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('005_Page_Opportunity/011_Quadro de Novo item da Oportunidade'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Inserir um produto para pesquisa '
WebUI.setText(findTestObject('005_Page_Opportunity/012_Inserir produto a ser pesquisado'), 'Grãos')

'Aguarde que o elemento de escolha fique visivel para clique'
WebUI.waitForElementClickable(findTestObject('005_Page_Opportunity/013_Clique no resultado do produto localizado'), 10)

'Clique no produto localizado após escrita'
WebUI.click(findTestObject('005_Page_Opportunity/013_Clique no resultado do produto localizado'))

'Clique para exibir a lista de tipos de serviços'
WebUI.click(findTestObject('005_Page_Opportunity/014_Clique na lista de Tipo de Serviço'))

'Selecione um valor do item de tipo de serviço na lista'
WebUI.click(findTestObject('005_Page_Opportunity/015_Selecione o tipo de serviço na lista'))

'Digite no campo a estacao origem '
WebUI.setText(findTestObject('005_Page_Opportunity/025_Campo de insercao da estacao O'), 'QA ORIGEM')

'Selecione a estação de origem'
WebUI.click(findTestObject('005_Page_Opportunity/026_Selecione a estacao O'))

'Digite no campo a estacao origem '
WebUI.setText(findTestObject('005_Page_Opportunity/027_Campo de insercao da estacao D'), 'QA DESTINO')

'Selecione a estação de origem'
WebUI.click(findTestObject('005_Page_Opportunity/028_Selecione a estacao D'))

'Inserir um valor no campo volume total'
WebUI.setText(findTestObject('005_Page_Opportunity/018_Inserir um valor no campo de Volume Total'), '100')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Salvar o item com sucesso.'
WebUI.click(findTestObject('005_Page_Opportunity/019_Clique em salvar apresentado no quadro'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na opção de novo pedido na tela da oportunidade'
WebUI.click(findTestObject('005_Page_Opportunity/020_Clique em novo pedido na tela'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Rolar a tela para a presença do campo'
WebUI.scrollToElement(findTestObject('007_Page_Pedidos/001_Numero do Pedido'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Rolar a tela para a presença do campo'
WebUI.scrollToElement(findTestObject('007_Page_Pedidos/002_Campo da Tabela de precos'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no botão de novo item do pedido'
WebUI.click(findTestObject('007_Page_Pedidos/003_Novo item do pedido'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('008_Page_Item do pedido/001_Quadro do item do pedido'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na flag de tipo de serviço'
WebUI.click(findTestObject('008_Page_Item do pedido/002_Expandir a lista de Tipo de Serviço'))

'Selecione o tipo do serviço na lista'
WebUI.click(findTestObject('008_Page_Item do pedido/003_Selecione o tipo de serviço'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('008_Page_Item do pedido/004_Digite no campo de estação origem'), 10)

'Digite no campo a estacao origem '
WebUI.setText(findTestObject('008_Page_Item do pedido/004_Digite no campo de estação origem'), 'QA ORIGEM')

'Selecione a estação de origem'
WebUI.click(findTestObject('008_Page_Item do pedido/005_Selecione a estacao de Origem'))

'Digite no campo de estação de destino'
WebUI.setText(findTestObject('008_Page_Item do pedido/006_Digite no campo estação de Destino'), 'QA DESTINO')

'Selecione no campo de estação de destino'
WebUI.click(findTestObject('008_Page_Item do pedido/007_ Selecione a estacao destino'))

'Inserir um produto no campo de Produto'
WebUI.setText(findTestObject('008_Page_Item do pedido/008_Campo de pesquisar produtos'), 'Grãos')

'Clica na opção que será apresantada'
WebUI.waitForElementClickable(findTestObject('008_Page_Item do pedido/009_Escolha do produto na lista apresentada'), 10)

'Clica na opção que será apresantada'
WebUI.click(findTestObject('008_Page_Item do pedido/009_Escolha do produto na lista apresentada'))

WebUI.scrollToElement(findTestObject('008_Page_Item do pedido/010_Abrir a lista de ano'), 100)

'Clique na flag de ano '
WebUI.click(findTestObject('008_Page_Item do pedido/010_Abrir a lista de ano'))

'Selecione o ano na lista'
WebUI.click(findTestObject('008_Page_Item do pedido/011_Selecione o ano'))

'Inserir um registro no campo volume do mês'
WebUI.setText(findTestObject('008_Page_Item do pedido/012_Inserir dados numerico na lista de volume'), '100')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique para salvar o item com sucesso'
WebUI.click(findTestObject('008_Page_Item do pedido/013_Clique para salvar o item com sucesso'))

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('008_Page_Item do pedido/014_Elemento Preço Base'), 10)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

WebUI.scrollToElement(findTestObject('008_Page_Item do pedido/014_Elemento Preço Base'), 30)

'Aguarde o carregamento da tela '
WebUI.waitForElementVisible(findTestObject('008_Page_Item do pedido/015_Elemento Contraproposta'), 10)

'Clique na flag da lista de contra proposta'
WebUI.click(findTestObject('008_Page_Item do pedido/015_Elemento Contraproposta'), FailureHandling.STOP_ON_FAILURE)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

