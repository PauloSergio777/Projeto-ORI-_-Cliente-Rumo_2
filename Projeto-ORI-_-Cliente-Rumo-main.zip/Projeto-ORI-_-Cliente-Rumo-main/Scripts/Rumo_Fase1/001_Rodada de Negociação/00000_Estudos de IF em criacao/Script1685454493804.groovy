import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'Abrir o navegador com a pagina inicial do SF'
WebUI.openBrowser(GlobalVariable.UrlDEV)

'Maximizar a tela do navegador'
WebUI.maximizeWindow()

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('001_Page_Login Salesforce/001_Imagem da tela de login'), 300)

'Inserir o usuario de acesso ao sistema '
WebUI.setText(findTestObject('001_Page_Login Salesforce/002_Usuario de acesso'), GlobalVariable.UsuarioDEV)

'Inserir a senha de acesso ao sistema'
WebUI.setText(findTestObject('001_Page_Login Salesforce/003_ Senha de acesso'), GlobalVariable.SenhaDEV)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Fazer login no sistema'
WebUI.click(findTestObject('001_Page_Login Salesforce/004_Botão de login_'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('002_Page_Home Salesforce/001_Quadro de desempenho da tela inicial do SF'), 300)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no iniciador de aplicativos "9 Bolinhas da tela inicial"'
WebUI.click(findTestObject('002_Page_Home Salesforce/002_Botão para menu de iniciador de aplicativos'))

'Digite no campo o objeto que devera ser acesso no sistema'
WebUI.setText(findTestObject('002_Page_Home Salesforce/003_Campo para pesquisa de aplicativos no SF'), 'Contas')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Selecione o objeto que foi digitado na busca '
WebUI.click(findTestObject('002_Page_Home Salesforce/004_Resultado APLICATIVOS na lista de iniciador de Aplicativos'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/001_Processamento da lista de contas'), 300)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Na tela da lista de contas selecione o botão de Criar'
WebUI.click(findTestObject('003_Page_Account/011_Clique do botão Criar'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/012_Selecione o tipo do registro de conta'), 300)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na escolha do tipo de Conta'
WebUI.click(findTestObject('003_Page_Account/012_Selecione o tipo do registro de conta'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em avançar após escolha do tipo'
WebUI.click(findTestObject('003_Page_Account/013_Clique de Avançar na tela de Nova Conta'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('003_Page_Account/014_Quadro de inserção de dados Nova Conta'), 300)

'Inserir um nome de conta no quadro'
WebUI.setText(findTestObject('003_Page_Account/015_Inserção de dados no campo nome da conta'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        1, 2))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

WebUI.click(findTestObject('003_Page_Account/018_Campo de insercao de CNPJ'))

'Clique para apresentar a lista de opções em Status'
WebUI.click(findTestObject('003_Page_Account/016_Abrir a flag de opcoes de status'))

'Clique em novo na lista de status'
WebUI.click(findTestObject('003_Page_Account/017_Selecione o novo de status'))

'Inserir CPNJ capturado na geracao'
WebUI.setText(findTestObject('003_Page_Account/018_Campo de insercao de CNPJ'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        2, 2))

'Inserir dados no campo Razao Social'
WebUI.setText(findTestObject('003_Page_Account/019_Inserção de dados da Razao Social'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        3, 2))

'Inserir dados no campo Inscrição estadual'
WebUI.setText(findTestObject('003_Page_Account/020_Inserir dados no campo Inscricao Estadual'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        4, 2))

'Inserir dados no campo de Ramo de Atividade'
WebUI.setText(findTestObject('003_Page_Account/021_Inserção de dados no campo Ramo de Atividade'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        5, 2))

'Clique para apresentar a lista de opções em Origem'
WebUI.click(findTestObject('003_Page_Account/022_Abrir a Flag de opcoes de origem'))

'Clique na opção de eventos na lista apresentada'
WebUI.click(findTestObject('003_Page_Account/023_Selecione Eventos na flag de origem'))

'Inserir um email no campo E-mail para envio NFE'
WebUI.setText(findTestObject('003_Page_Account/024_inserção de dados no campo E-mail para envio NFE'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        6, 2))

'Inserir um email no campo E-mail para envio CTE'
WebUI.setText(findTestObject('003_Page_Account/025_inserção de dados no campo E-mail para envio CTE'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        7, 2))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Avançar após inserir os dados da nova conta'
WebUI.click(findTestObject('003_Page_Account/026_Clique Salvar Conta'))

if (true) {
    WebUI.verifyElementPresent(findTestObject('000_IFs de validacao/001_Informacao criacao de conta'), 15)

    ErroCriacao = WebUI.getText(findTestObject('000_IFs de validacao/002_Texto da informacao', [('variable') : ErroCriacao]))

    System.out.println(ErroCriacao)

    WebUI.comment(ErroCriacao)

    WebUI.takeScreenshot()

    WebUI.closeBrowser()
}

if (false) {
    WebUI.verifyElementPresent(findTestObject('000_IFs de validacao/001_Informacao criacao de conta'), 15)

    'Tirar a evidencia da tela '
    WebUI.takeScreenshot()

    'Aguarde a pagina ser carregada com sucesso'
    WebUI.waitForElementVisible(findTestObject('003_Page_Account/027_Valide a presenca do campo Informacoes de Conta'), 
        300)

    'Tirar a evidencia da tela '
    WebUI.takeScreenshot()
}

