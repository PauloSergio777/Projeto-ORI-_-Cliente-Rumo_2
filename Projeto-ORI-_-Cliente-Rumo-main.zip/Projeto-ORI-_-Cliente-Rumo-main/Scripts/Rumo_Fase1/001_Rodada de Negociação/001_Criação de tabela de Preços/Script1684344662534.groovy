import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'Abrir o navegador com a pagina inicial do SF'
WebUI.openBrowser(GlobalVariable.UrlDEV)

'Maximizar a tela do navegador'
WebUI.maximizeWindow()

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('001_Page_Login Salesforce/001_Imagem da tela de login'), 30)

'Inserir o usuario de acesso ao sistema '
WebUI.setText(findTestObject('001_Page_Login Salesforce/002_Usuario de acesso'), GlobalVariable.UsuarioDEV)

'Inserir a senha de acesso ao sistema'
WebUI.setText(findTestObject('001_Page_Login Salesforce/003_ Senha de acesso'), GlobalVariable.SenhaDEV)

'Tirar a evidencia da tela apresentada'
WebUI.takeScreenshot()

'Fazer login no sistema'
WebUI.click(findTestObject('001_Page_Login Salesforce/004_Botão de login_'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('002_Page_Home Salesforce/001_Quadro de desempenho da tela inicial do SF'), 30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no iniciador de aplicativos "9 Bolinhas da tela inicial"'
WebUI.click(findTestObject('002_Page_Home Salesforce/002_Botão para menu de iniciador de aplicativos'))

'Digite no campo o objeto que devera ser acesso no sistema'
WebUI.setText(findTestObject('002_Page_Home Salesforce/003_Campo para pesquisa de aplicativos no SF'), 'Tabelas de preços')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Selecione o objeto que foi digitado na busca '
WebUI.click(findTestObject('002_Page_Home Salesforce/004_Resultado APLICATIVOS na lista de iniciador de Aplicativos'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Na tela da lista de contas selecione o botão de Criar'
WebUI.click(findTestObject('003_Page_Account/011_Clique do botão Criar'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('006_Page_Tabela_precos/001_Nome da Tabela de precos'), 30)

'Inserir o nome da tabela de preço que será criada'
WebUI.setText(findTestObject('006_Page_Tabela_precos/001_Nome da Tabela de precos'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        8, 2))

'Selecione o checkbox para deixar a tabela ativa'
WebUI.click(findTestObject('006_Page_Tabela_precos/002_Selecione o checkbox Ativo'))

'O sistema devera permitir inserir a data base'
WebUI.setText(findTestObject('006_Page_Tabela_precos/003_Inserir Data base'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        9, 2))

'Abrir a lista de ano de referencia\r\n'
WebUI.click(findTestObject('006_Page_Tabela_precos/004_Selecione a lista para o Ano Referencia'))

'Clique em um ano na lista'
WebUI.click(findTestObject('006_Page_Tabela_precos/005_Clique no ano referencia na lista'))

'Inserir uma data no campo Data inicio vigencia'
WebUI.setText(findTestObject('006_Page_Tabela_precos/006_Inserir inicio data vigencia'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        10, 2))

'Inserir uma data no campo fim de vigencia'
WebUI.setText(findTestObject('006_Page_Tabela_precos/007_Inserir data fim de vigencia'), findTestData('Dados_RodadaNegociacaoRumo').getValue(
        11, 2))

'Clique a lista de opções de carteira'
WebUI.click(findTestObject('006_Page_Tabela_precos/008_Selecione a lista de carteira'))

'Clique no resultado da lista de carteiras'
WebUI.click(findTestObject('006_Page_Tabela_precos/009_Clique na opcao de carteira'))

'Clique na lista de Opções Operação'
WebUI.click(findTestObject('006_Page_Tabela_precos/010_Selecione a lista de Operação'))

'Clique no resultado da lista de operação'
WebUI.click(findTestObject('006_Page_Tabela_precos/011_Clique na opcao de Operação'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique na lista de opções de Tipo de Serviço'
WebUI.click(findTestObject('006_Page_Tabela_precos/012_Selecione a lista de Tipo de Serviço'))

'Clique no resultado da lista de tipo de serviço'
WebUI.click(findTestObject('006_Page_Tabela_precos/013_Clique na opcao de Tipo de Serviço'))

'Clique na lista de opções de Fonte'
WebUI.click(findTestObject('006_Page_Tabela_precos/014_Selecione a lista de Fonte'))

'Clique no resultado da lista de Fonte'
WebUI.click(findTestObject('006_Page_Tabela_precos/015_Clique na opcao de fonte'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Salvar a tabela de preços criada'
WebUI.click(findTestObject('006_Page_Tabela_precos/016_Salvar a tabela de preço criada'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'localize na tela o campo do elemento'
WebUI.scrollToElement(findTestObject('006_Page_Tabela_precos/017_Campo de Informacoes do sistema'), 30)

'localize na tela o campo do elemento'
WebUI.scrollToElement(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/001_Localize o campo de TP_Entrada de Preco'), 
    30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique no botão de criar '
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/002_Botao criar TP_EntradaPrecos'))

'Aguarde a pagina ser carregada com sucesso'
WebUI.waitForElementVisible(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/003_Quadro de Criar TP - Entrada de preco'), 
    30)

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Digite no campo de pesquisa o produto'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/004_Campo de pesquisar produtos'), 
    findTestData('Dados_RodadaNegociacaoRumo').getValue(12, 2))

'Clique na opcao apresentada na lista'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/005_Escolha do produto na lista apresentada'))

'Clique na lista que sera apresentada de tipo de entrada'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/006_Abrir a lista do tipo de entrada'))

'Clique em Serviço na lista de tipo de entrada'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/007_Selecione o tipo de entrada'))

'Clique na lista de tipo de serviço no sistema'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/008_Abrir a lista de tipo de servico'))

'Clique no tipo de serviço na lista'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/009_Selecione o tipo de serviço'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'localize na tela o campo do elemento'
WebUI.scrollToElement(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/010_Digite no campo de estação origem'), 
    30)

'Digite no campo de pesquisa a estacao origem'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/010_Digite no campo de estação origem'), 
    findTestData('Dados_RodadaNegociacaoRumo').getValue(13, 2))

'Clique no resultado da lista apresentada'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/011_Selecione a estacao'))

'Digite no campo de pesquisa da estacao destino'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/012_Digite no campo de estação destino'), 
    findTestData('Dados_RodadaNegociacaoRumo').getValue(14, 2))

'Clique na primeira opcao na lista'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/013_Selecione a primeira opcao na lista'))

'Clique para exibir a lista de corredor'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/014_Abrir a lista do tipo do corredor'))

'Clique na lista o tipo de corredor'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/015_Selecione o tipo de Corredor'))

'Digite a praça de destino'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/036_Inserir Praça Destino'), 'teste')

'selecione a praça de destino'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/037_Escolha na lista a opcao de praca destino'))

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/016_Inserir mix base_Jan'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/017_Inserir mix base_Fev'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/018_Inserir mix base_Mar'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/019_Inserir mix base_Abr'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/020_Inserir mix base_Maio'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/021_Inserir mix base_Jun'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/022_Inserir mix base_Jul'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/023_Inserir mix base_Ago'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/024_Inserir mix base_Set'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/025_Inserir mix base_Out'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/026_Inserir mix base_Nov'), '100')

'Inserir valor no campo de Mix Base de acordo com o mes'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/027_Inserir mix base_Dez'), '100')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'localize na tela o campo do elemento'
WebUI.scrollToElement(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/028_Abrir a lista do Tipo de Tarifa'), 
    30)

'Clique para a lista de Tipo Tarifa no sistema'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/028_Abrir a lista do Tipo de Tarifa'))

'Clique na opcao de Tipo tarifa'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/029_Selecione o tipo tarifa'))

'Clique para exibir a lista de ano no sistema'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/030_Abrir a lista de ano'))

'Clique para selecionar o ano desejado'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/031_Selecione o ano'))

'Inserir um valor no campo de preco ano'
WebUI.setText(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/032_inserir o Preco Ano'), '100')

'Tirar a evidencia da tela '
WebUI.takeScreenshot()

'Clique em Salvar a entrada de preco criada'
WebUI.click(findTestObject('006_Page_Tabela_precos/Z006.1_Tabela _ Entrada de precos/033_Clique em Salvar a Entrada de preco'))

